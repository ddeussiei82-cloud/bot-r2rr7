import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk, ImageEnhance
import openai
import os
import shutil
import zipfile
import json

# ضع مفتاح OpenAI الخاص بك
openai.api_key = "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"

def generate_mod():
    mod_name = mod_name_entry.get()
    mod_idea = mod_idea_text.get("1.0", tk.END).strip()
    game_name = game_name_entry.get()
    image_path = image_path_var.get()
    mod_type = mod_type_combo.get()
    platform = platform_combo.get()

    if not mod_name or not mod_idea or not game_name or not image_path or not mod_type or not platform:
        messagebox.showerror("ﺄﻄﺧ", "!ﺔﺼﻨﻤﻟﺍﻭ ﺩﻮﻤﻟﺍ ﻉﻮﻧ ،ﺓﺭﻮﺼﻟﺍ ﺭﺎﻴﺘﺧﺍﻭ ﻝﻮﻘﺤﻟﺍ ﻊﻴﻤﺟ ﺀﻞﻣ ﻰﺟﺮﻳ")
        return

    try:
        processed_image_path = process_image(image_path, mod_name)

        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "أنت مبرمج Minecraft Mod خبير."},
                {"role": "user", "content": f"اصنع كود مود Minecraft باسم '{mod_name}', ﻉﻮﻧ: '{mod_type}', فكرة: '{mod_idea}', اسم داخل اللعبة: '{game_name}', اربطه بالصورة '{os.path.basename(processed_image_path)}', ﺔﺼﻨﻣ ﻊﻣ ﻖﻓﺍﻮﺘﻣ ﺩﻮﻤﻟﺍ ﻞﻌﺟﻭ ،ﺩﻮﻜﻟﺍ ﻲﻓ ﺄﻄﺧ ﻱﺃ ﺢﺤﺻ {platform}."}
            ],
            temperature=0.5
        )
        mod_code = response.choices[0].message.content

        output_dir = f"{mod_name}_mod"
        os.makedirs(output_dir, exist_ok=True)
        src_dir = os.path.join(output_dir, "src/main/java")
        res_dir = os.path.join(output_dir, "src/main/resources/assets", mod_name)
        os.makedirs(src_dir, exist_ok=True)
        os.makedirs(res_dir, exist_ok=True)

        code_file = os.path.join(src_dir, f"{mod_name}.java")
        with open(code_file, "w", encoding="utf-8") as f:
            f.write(mod_code)

        shutil.copy(processed_image_path, os.path.join(res_dir, os.path.basename(processed_image_path)))

        if platform == "Forge":
            with open(os.path.join(output_dir, "build.gradle"), "w") as f:
                f.write(f"// build.gradle placeholder for Forge mod {mod_name}")
        else:
            fabric_json = {
                "schemaVersion": 1,
                "id": mod_name.lower(),
                "version": "1.0.0",
                "name": game_name,
                "description": mod_idea,
                "authors": ["FURY AI"],
                "entrypoints": {"main": [f"{mod_name}"]},
                "depends": {}
            }
            with open(os.path.join(output_dir, "fabric.mod.json"), "w") as f:
                json.dump(fabric_json, f, indent=4)

        jar_file = f"{mod_name}.jar"
        with zipfile.ZipFile(jar_file, 'w') as jar:
            jar.write(code_file, arcname=f"{mod_name}.java")
            for img_file in os.listdir(res_dir):
                jar.write(os.path.join(res_dir, img_file), arcname=os.path.join("assets", mod_name, img_file))
            if platform == "Forge":
                jar.write(os.path.join(output_dir, "build.gradle"), arcname="build.gradle")
            else:
                jar.write(os.path.join(output_dir, "fabric.mod.json"), arcname="fabric.mod.json")

        messagebox.showinfo("تم", f"تم إنشاء المود بنجاح!\nمجلد المشروع: {output_dir}\nملف Jar جاهز: {jar_file}")

    except Exception as e:
        messagebox.showerror("خطأ", f"حدث خطأ أثناء إنشاء المود: {e}")

def choose_image():
    path = filedialog.askopenfilename(filetypes=[("صور PNG", "*.png"), ("صور JPG", "*.jpg;*.jpeg")])
    if path:
        image_path_var.set(path)
        load_preview(path)

def load_preview(path):
    img = Image.open(path)
    img.thumbnail((150,150))
    img_tk = ImageTk.PhotoImage(img)
    image_preview_label.config(image=img_tk)
    image_preview_label.image = img_tk

def process_image(path, mod_name):
    img = Image.open(path).convert("RGBA")
    img = ImageEnhance.Color(img).enhance(0.7)
    img = ImageEnhance.Brightness(img).enhance(1.1)
    img = img.resize((64,64), Image.Resampling.LANCZOS)
    processed_path = f"{mod_name}_processed.png"
    img.save(processed_path)
    return processed_path

# ======================
# واجهة المستخدم
# ======================
root = tk.Tk()
root.title("FURY Minecraft Mod Builder AI")
root.geometry("700x700")
root.configure(bg="#2b2b3a")

frame = tk.Frame(root, bg="#2b2b3a")
frame.pack(expand=True, anchor="center")

label_style = {"bg": "#2b2b3a", "fg": "white", "font": ("Arial", 12)}
entry_width = 40

# استخدام pack لتوسيط كل العناصر بشكل دقيق
tk.Label(frame, text="اسم المود:", **label_style).pack(pady=5)
mod_name_entry = tk.Entry(frame, width=entry_width)
mod_name_entry.pack(pady=5)

tk.Label(frame, text="نوع المود:", **label_style).pack(pady=5)
mod_type_combo = ttk.Combobox(frame, values=["Tools", "Blocks", "Mobs"], state="readonly", width=38)
mod_type_combo.pack(pady=5)

tk.Label(frame, text="فكرة الكود:", **label_style).pack(pady=5)
mod_idea_text = tk.Text(frame, width=35, height=6)
mod_idea_text.pack(pady=5)

tk.Label(frame, text="صورة المود:", **label_style).pack(pady=5)
image_frame = tk.Frame(frame, bg="#2b2b3a")
image_frame.pack(pady=5)
image_path_var = tk.StringVar()
tk.Entry(image_frame, textvariable=image_path_var, width=30).pack(side="left", padx=5)
tk.Button(image_frame, text="اختر الصورة", command=choose_image, bg="#4caf50", fg="white", width=12).pack(side="left", padx=5)

image_preview_label = tk.Label(frame, bg="#2b2b3a")
image_preview_label.pack(pady=5)

tk.Label(frame, text="اسم المود داخل اللعبة:", **label_style).pack(pady=5)
game_name_entry = tk.Entry(frame, width=entry_width)
game_name_entry.pack(pady=5)

tk.Label(frame, text="اختر المنصة:", **label_style).pack(pady=5)
platform_combo = ttk.Combobox(frame, values=["Forge", "Fabric"], state="readonly", width=38)
platform_combo.pack(pady=5)

tk.Button(frame, text="إنشاء المود", command=generate_mod, bg="#ff5722", fg="white",
          width=20, font=("Arial", 12, "bold")).pack(pady=20)

root.mainloop()