#!/data/data/com.termux/files/usr/bin/bash
# ============================================
# 🥊 MUAYTHAI - AUTO DOWNLOAD & DELETE 🥊
# ============================================

clear

# ألوان
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# ============================================
# شريط تقدم متحرك
# ============================================
progress_bar() {
    echo -n "["
    for i in {1..50}; do
        echo -n "█"
        sleep 0.03
    done
    echo "] 100%"
}

# ============================================
# العرض
# ============================================
echo -e "${PURPLE}"
echo "╔══════════════════════════════════════════╗"
echo "║         🥊 ASEM VIP INSTALLER           ║"
echo "║     Download & Setup - One Time Only     ║"
echo "╚══════════════════════════════════════════╝"
echo -e "${NC}"
echo ""

# ============================================
# 1. تحقق من المتطلبات
# ============================================
echo -e "${YELLOW}[1/4] 📦 Checking requirements...${NC}"
progress_bar

pkg update -y > /dev/null 2>&1
if ! command -v wget &> /dev/null; then
    pkg install wget -y > /dev/null 2>&1
fi

echo -e "${GREEN}✅ Requirements OK${NC}"
echo ""

# ============================================
# 2. تنزيل من GitHub
# ============================================
echo -e "${YELLOW}[2/4] 📥 Downloading from GitHub...${NC}"

# 🔗 رابطك المباشر
GITHUB_URL="https://github.com/qweryuio2005/MuayThai/raw/77bb46f0d66415f4c27742882e72f8fd6252174d/MuayThai.sh"

echo -e "${CYAN}🔗 Source: $GITHUB_URL${NC}"
echo ""

progress_bar

# تحميل
if wget -q "$GITHUB_URL" -O muaythai_main.sh; then
    echo -e "${GREEN}✅ Download successful${NC}"
else
    echo -e "${RED}❌ Download failed${NC}"
    exit 1
fi

# ============================================
# 3. صلاحيات + إنشاء mi
# ============================================
echo -e "${YELLOW}[3/4] 🔧 Setting up...${NC}"

# صلاحيات تنفيذ
chmod +x muaythai_main.sh

# إنشاء أمر mi
cat > /data/data/com.termux/files/usr/bin/mi << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
# 🥊 mi - MuayThai Tool
bash "$HOME/muaythai_main.sh"
EOF

chmod +x /data/data/com.termux/files/usr/bin/mi

# نقل للبيت
mv muaythai_main.sh "$HOME/muaythai_main.sh"

echo -e "${GREEN}✅ Setup complete${NC}"
echo ""

# ============================================
# 4. حذف المثبت
# ============================================
echo -e "${YELLOW}[4/4] 🗑️  Cleaning up...${NC}"

echo -e "${RED}⚠️  This installer will self-destruct${NC}"
sleep 2

# حذف الملف الحالي
rm -f "$0"

echo -e "${GREEN}✅ Installer removed${NC}"
echo ""

# ============================================
# النتيجة النهائية
# ============================================
echo -e "${PURPLE}========================================${NC}"
echo -e "${GREEN}🎉 MUAYTHAI INSTALLED SUCCESSFULLY!${NC}"
echo -e "${PURPLE}========================================${NC}"
echo ""
echo -e "${CYAN}📁 Installed files:${NC}"
echo "   ~/muaythai_main.sh"
echo "   /usr/bin/mi"
echo ""
echo -e "${YELLOW}🚀 Usage:${NC}"
echo "   Type: ${GREEN}mi${NC}"
echo ""
echo -e "${BLUE}📢 Telegram:${NC}"
echo "   https://t.me/+Fn0ygDD1owhjMzZi"
echo ""
echo -e "${YELLOW}Launching MuayThai now...${NC}"
echo ""
sleep 2

# تشغيل الأداة
bash "$HOME/muaythai_main.sh"