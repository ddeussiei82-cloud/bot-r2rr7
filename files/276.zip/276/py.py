import marshal
import zlib
import base64
import importlib.util
import struct
import time

# 1. اسم الملف المشفر الخاص بك
encrypted_filename = '#1 TikTok Alvailables Hot 🔥.py'

print(f"[*] جاري قراءة الملف المشفر: {encrypted_filename} ...")
with open(encrypted_filename, 'r', encoding='utf-8') as file:
    content = file.read()

# 2. عزل الجزء المشفر من الكود
start = content.find("b'") + 2
end = content.rfind("')")
encrypted_payload = content[start:end].encode('utf-8')

# 3. اختراق وتجريد طبقات التشفير
reversed_payload = encrypted_payload[::-1]
decoded_b64 = base64.b64decode(reversed_payload)
decompressed_zlib = zlib.decompress(decoded_b64)

# الآن لدينا كودك الأصلي كـ (Bytecode)
original_code_obj = marshal.loads(decompressed_zlib)

# 4. بناء ملف بايثون مترجم (.pyc) لوضع الكود فيه
pyc_filename = 'decrypted_bytecode.pyc'
print("[*] جاري حقن الكود وتوليد الملف الجديد...")

with open(pyc_filename, 'wb') as pyc_file:
    # كتابة الترويسة القياسية لبايثون (تدعم إصدارات 3.7 وما فوق)
    pyc_file.write(importlib.util.MAGIC_NUMBER)
    pyc_file.write(struct.pack('<L', 0)) # Bitfield
    pyc_file.write(struct.pack('<L', int(time.time()))) # Timestamp
    pyc_file.write(struct.pack('<L', 0)) # Size
    
    # حفظ كودك داخل الملف الجديد بدون التشفير
    marshal.dump(original_code_obj, pyc_file)

print(f"✅ نجاح! تم استخراج ملفك وحفظه باسم: {pyc_filename}")
