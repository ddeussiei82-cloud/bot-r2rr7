import requests
import random
from user_agent import generate_user_agent as ua
import time
import os

Z = '\033[1;31m'
X = '\033[1;33m'
F = '\033[2;32m'

C = '\033[2;32m'
tok = input(f' {F} TOKEN {X} : {F}'+C)
ID = input(f' {F}ID {X}    : {F}  '+C)




def send_msg(user):
    msg = f"--\n user: {user}\n"
    url = f"https://api.telegram.org/bot{tok}/sendMessage"
    data = {"chat_id": ID, "text": msg}
    try:
        requests.post(url, data=data)
    except:
        pass

def generate_username():
    digits = '1234567890'
    letters = 'qwertyuiopasdfghjklzxcvbnm'
    sss = '_'
    part1 = ''.join(random.choice(digits) for _ in range(2))
    part2 = ''.join(random.choice(letters) for _ in range(2))
    part3 = ''.join(random.choice(sss) for _ in range(1))
    return part1 + part2 + part3

def check_username(user):
    url = 'https://www.mediamister.com/get_tiktok_handle'
 
    headers = {
        'authority': 'www.mediamister.com',
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'origin': 'https://www.mediamister.com',
        'referer': 'https://www.mediamister.com/tiktok-username-checker',
        'user-agent': ua(),
        'x-requested-with': 'XMLHttpRequest',
    }
    data = {'recaptcha': '', 'username': user}

    try:
        r = requests.post(url, headers=headers, data=data, timeout=10)
        print(r.text)
        if 'username is available' in r.text:
            print(f'{F} God user: {user}')
            send_msg(user)
            with open('available.txt', 'a') as f:
                f.write(user + '\n')
        else:
            print(f'{Z} Bad User: {user}')
    except:
        pass

while True:
    user = generate_username()
    check_username(user)
    time.sleep(3)