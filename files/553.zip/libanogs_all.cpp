// All Instructions
// Generated: 2026-07-28 05:07:48.093363
// Channel: https://t.me/KBTANTT

PATCH_LIB("libanogs.so","0x0","D8 B1 D8 A7"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x4","D8 A8 D8 B7"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x8","20 D8 AA D8"); // NORMAL: INS
PATCH_LIB("libanogs.so","0xC","AD D9 85 D9"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x10","8A D9 84 20"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x14","D8 A7 D9 84"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x18","D8 AA D8 B7"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x1C","D8 A8 D9 8A"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x20","D9 82 20 0D"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x24","0A 0D 0A 68"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x78","67 0D 0A 0D"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x7C","0A D9 83 D9"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x80","84 D9 85 D9"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x84","87 20 D8 B3"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x88","D8 B1 20 D9"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x8C","81 D9 83 20"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x90","D8 A7 D9 84"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x94","D8 B6 D8 BA"); // NORMAL: INS
PATCH_LIB("libanogs.so","0x98","D8 B7 20 0D"); // NORMAL: INS
