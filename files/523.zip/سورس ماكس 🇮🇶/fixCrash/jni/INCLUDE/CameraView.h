#ifndef XT_CameraView_H
#define XT_CameraView_H

struct FMatrix {
    float M[4][4];
};
struct FRotator {
    float Pitch;
    float Yaw;
    float Roll;
};
struct CameraView {
    Vec3 Location;
    Vec3 LocationLocalSpace;
    FRotator Rotation;
    float FOV;
};
CameraView cameraView = CameraView();
CameraView getCameraView(uintptr_t address) {
    CameraView buff;
    vm_readv(address, &buff, sizeof(CameraView));
    return buff;
}
FRotator ToRotator(Vec3 local, Vec3 target) {
    Vec3 rotation;
    rotation.X = local.X - target.X;
    rotation.Y = local.Y - target.Y;
    rotation.Z = local.Z - target.Z;

    FRotator newViewAngle = {0};

    float hyp = sqrt(rotation.X * rotation.X + rotation.Y * rotation.Y);

    newViewAngle.Pitch = -atan(rotation.Z / hyp) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Yaw = atan(rotation.Y / rotation.X) * (180.f / (float) 3.14159265358979323846);
    newViewAngle.Roll = (float) 0.f;

    if (rotation.X >= 0.f)
        newViewAngle.Yaw += 180.0f;

    return newViewAngle;
}

Vec3 MarixToVector(FMatrix matrix) {
    return Vec3(matrix.M[3][0], matrix.M[3][1], matrix.M[3][2]);
}
FMatrix MatrixMulti(FMatrix m1, FMatrix m2) {
    FMatrix matrix = FMatrix();
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                matrix.M[i][j] += m1.M[i][k] * m2.M[k][j];
            }
        }
    }
    return matrix;
}
FMatrix RotToMatrix(FRotator rotation) {
    float radPitch = rotation.Pitch * ((float)M_PI / 180.0f);
    float radYaw = rotation.Yaw * ((float)M_PI / 180.0f);
    float radRoll = rotation.Roll * ((float)M_PI / 180.0f);

    float SP = sinf(radPitch);
    float CP = cosf(radPitch);
    float SY = sinf(radYaw);
    float CY = cosf(radYaw);
    float SR = sinf(radRoll);
    float CR = cosf(radRoll);

    FMatrix matrix;

    matrix.M[0][0] = (CP * CY);
    matrix.M[0][1] = (CP * SY);
    matrix.M[0][2] = (SP);
    matrix.M[0][3] = 0;

    matrix.M[1][0] = (SR * SP * CY - CR * SY);
    matrix.M[1][1] = (SR * SP * SY + CR * CY);
    matrix.M[1][2] = (-SR * CP);
    matrix.M[1][3] = 0;

    matrix.M[2][0] = (-(CR * SP * CY + SR * SY));
    matrix.M[2][1] = (CY * SR - CR * SP * SY);
    matrix.M[2][2] = (CR * CP);
    matrix.M[2][3] = 0;

    matrix.M[3][0] = 0;
    matrix.M[3][1] = 0;
    matrix.M[3][2] = 0;
    matrix.M[3][3] = 1;

    return matrix;
}

Vec2 World2ScreenMain(CameraView camViewInfo, Vec3 worldLocation) {
    FMatrix tempMatrix = RotToMatrix(camViewInfo.Rotation);
    Vec3 vAxisX(tempMatrix.M[0][0], tempMatrix.M[0][1], tempMatrix.M[0][2]);
    Vec3 vAxisY(tempMatrix.M[1][0], tempMatrix.M[1][1], tempMatrix.M[1][2]);
    Vec3 vAxisZ(tempMatrix.M[2][0], tempMatrix.M[2][1], tempMatrix.M[2][2]);
    Vec3 vDelta = worldLocation - camViewInfo.Location;
    Vec3 vTransformed(Vec3::Dot(vDelta, vAxisY), Vec3::Dot(vDelta, vAxisZ), Vec3::Dot(vDelta, vAxisX));

    if (vTransformed.Z < 1.0f) { vTransformed.Z = 1.0f;}

    float fov = camViewInfo.FOV;
    float screenCenterX = (width / 2.0f);
    float screenCenterY = (height / 2.0f);

    Vec2 vec2;
    vec2.X = screenCenterX + vTransformed.X * (screenCenterX / tanf(fov * ((float)M_PI / 360))) / vTransformed.Z;
    vec2.Y = screenCenterY - vTransformed.Y * (screenCenterX / tanf(fov * ((float)M_PI / 360))) / vTransformed.Z;
    return vec2;
}

Vec3 World2Screen(CameraView camViewInfo, Vec3 worldLocation) {
    FMatrix tempMatrix = RotToMatrix(camViewInfo.Rotation);
    Vec3 vAxisX(tempMatrix.M[0][0], tempMatrix.M[0][1], tempMatrix.M[0][2]);
    Vec3 vAxisY(tempMatrix.M[1][0], tempMatrix.M[1][1], tempMatrix.M[1][2]);
    Vec3 vAxisZ(tempMatrix.M[2][0], tempMatrix.M[2][1], tempMatrix.M[2][2]);
    Vec3 vDelta = worldLocation - camViewInfo.Location;
    Vec3 vTransformed(Vec3::Dot(vDelta, vAxisY), Vec3::Dot(vDelta, vAxisZ), Vec3::Dot(vDelta, vAxisX));

    if (vTransformed.Z < 1.0f) { vTransformed.Z = 1.0f;}

    float fov = camViewInfo.FOV;
    float screenCenterX = (width / 2.0f);
    float screenCenterY = (height / 2.0f);

    Vec3 vec3;

    if (tanf(fov * ((float)M_PI / 360)) < 0.01f)
        vec3.Z = 1;
    else
        vec3.Z = 0;
    vec3.X = screenCenterX + vTransformed.X * (screenCenterX / tanf(fov * ((float)M_PI / 360))) / vTransformed.Z;
    vec3.Y = screenCenterY - vTransformed.Y * (screenCenterX / tanf(fov * ((float)M_PI / 360))) / vTransformed.Z;
    return vec3;
}

#endif //XT_CameraView_H



