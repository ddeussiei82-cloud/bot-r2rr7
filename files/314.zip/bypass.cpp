PATCH_LIB("libUE4.so", "0x3D3B694", "49 6E 69 74 4D 6F 6E 69"); // InitMonitorDataPtr
PATCH_LIB("libUE4.so", "0x3DAC00C", "41 74 6D 6F 73 50 6C 75"); // AtmosPlugin atmos_5_1_2 monitoring.
PATCH_LIB("libUE4.so", "0x3DD14B4", "70 6F 73 73 69 62 6C 79"); // possibly monitoring progress in detail with the -vv flag.
PATCH_LIB("libUE4.so", "0x3E0C130", "4D 6F 76 65 53 70 65 65"); // MoveSpeedParamMonitorStrategy
PATCH_LIB("libUE4.so", "0x3E5F138", "44 3A 5C 52 65 6C 65 61"); // D:\Release4.3.0\AS\Survive\Source\ShadowTrackerExtra\UI\UIManager\UIMonitorManager.cpp

// ========== Tss ==========
PATCH_LIB("libUE4.so", "0x3C57BC8", "4F 6E 52 53 54 53 53 70"); // OnRSTSSpeechToTextCallback
PATCH_LIB("libUE4.so", "0x3C8ED40", "53 65 74 4D 65 73 68 53"); // SetMeshSectionCastsShadow
PATCH_LIB("libUE4.so", "0x3CAB040", "42 72 6F 61 64 63 61 73"); // BroadcastClientsSimulateMeleeDamage
PATCH_LIB("libUE4.so", "0x3CAB064", "42 72 6F 61 64 63 61 73"); // BroadcastClientsSimulateRadialDamageDie
PATCH_LIB("libUE4.so", "0x3CC192C", "42 72 6F 61 64 63 61 73"); // BroadcastClientsSimulateVehicleDamageDie

// ========== Cheat ==========
PATCH_LIB("libUE4.so", "0x3C5DA90", "41 6E 74 69 43 68 65 61"); // AntiCheatRandValue3
PATCH_LIB("libUE4.so", "0x3C71FCC", "43 6C 69 65 6E 74 43 68"); // ClientCheatWalk
PATCH_LIB("libUE4.so", "0x3CA029C", "44 3A 5C 52 65 6C 65 61"); // D:\Release4.3.0\AS\Survive\Source\Development\GMCheat\GMCheatLevel.cpp
PATCH_LIB("libUE4.so", "0x3CAF0E4", "41 6E 74 69 43 68 65 61"); // AntiCheatDetailData
PATCH_LIB("libUE4.so", "0x3CB62B4", "43 68 65 61 74 42 65 67"); // CheatBeginPlay

// ========== Report ==========
PATCH_LIB("libUE4.so", "0x2DCE984", "5F 5A 4E 36 47 43 6C 6F"); // _ZN6GCloud10CrashSight21CrashSightMobileAgent19ConfigCrashReporterEi
PATCH_LIB("libUE4.so", "0x3C576BC", "47 65 74 42 75 67 52 65"); // GetBugReporter
PATCH_LIB("libUE4.so", "0x3C5828C", "45 52 65 61 6C 74 69 6D"); // ERealtimeReportType
PATCH_LIB("libUE4.so", "0x3C5ECAC", "47 4D 53 65 6E 64 44 61"); // GMSendDailyTaskReport
PATCH_LIB("libUE4.so", "0x3C6A70C", "62 45 6E 61 62 6C 65 44"); // bEnableDSErrorLogReport

// ========== Server ==========
PATCH_LIB("libUE4.so", "0x2DCB8D4", "5F 5A 4E 33 55 51 4D 38"); // _ZN3UQM8UQMCrash19SetCrashLogObserverEPNS_19UQMCrashLogObserverE
PATCH_LIB("libUE4.so", "0x2DCEB58", "5F 5A 4E 34 69 6E 74 6C"); // _ZN4intl10Compliance21SetComplianceObserverEPNS_18ComplianceObserverE
PATCH_LIB("libUE4.so", "0x3C4F018", "49 67 6E 6F 72 65 56 61"); // IgnoreVaultingServerCheck
PATCH_LIB("libUE4.so", "0x3C51ACC", "4F 6E 52 65 70 5F 53 65"); // OnRep_ServerBulletSpeed
PATCH_LIB("libUE4.so", "0x3C56784", "53 65 72 76 65 72 4A 75"); // ServerJump_Vehicle4W

// ========== Path ==========
PATCH_LIB("libUE4.so", "0x3C4F828", "44 65 66 61 75 6C 74 4C"); // DefaultLuaFilePath
PATCH_LIB("libUE4.so", "0x3C571DC", "49 73 41 76 61 74 61 72"); // IsAvatarResPathExist
PATCH_LIB("libUE4.so", "0x3C57414", "43 6F 6E 76 65 72 74 47"); // ConvertGamePathToRelativeFilePath
PATCH_LIB("libUE4.so", "0x3C583F8", "62 56 61 6C 69 64 54 6F"); // bValidTogetherPath
PATCH_LIB("libUE4.so", "0x3C5BB44", "50 61 74 68 4F 70 74 69"); // PathOptimizationInterval

// ========== traceback ==========
PATCH_LIB("libUE4.so", "0x3F477D8", "73 74 61 63 6B 20 74 72"); // stack traceback:
PATCH_LIB("libUE4.so", "0x4018368", "74 72 61 63 65 62 61 63"); // traceback

// ========== aLog ==========
PATCH_LIB("libUE4.so", "0x2DCC72C", "5F 5A 4E 35 41 42 61 73"); // _ZN5ABase4XLogEN6GCloud12ALogPriorityEPKcjS3_S3_z
PATCH_LIB("libUE4.so", "0x3C56DD8", "4F 70 65 6E 4F 72 43 6C"); // OpenOrCloseLuaLog
PATCH_LIB("libUE4.so", "0x3C9F9F0", "4F 6E 52 65 6D 6F 76 65"); // OnRemoveLuaLogicManagerEvent
PATCH_LIB("libUE4.so", "0x3CBC5AC", "41 6E 64 72 6F 69 64 54"); // AndroidThunkJava_HideVirtualKeyboardInputDialog
PATCH_LIB("libUE4.so", "0x3D39970", "62 41 6E 61 6C 6F 67 4D"); // bAnalogMode

// ========== AnoSDKIoctlOld ==========
PATCH_LIB("libUE4.so", "0x2DCB2A0", "41 6E 6F 53 44 4B 49 6F"); // AnoSDKIoctlOld

// ========== AnoSDKOnRecvData ==========
PATCH_LIB("libUE4.so", "0x2DCBA30", "41 6E 6F 53 44 4B 4F 6E"); // AnoSDKOnRecvData

// ========== AnoSDKIoctl ==========
PATCH_LIB("libUE4.so", "0x2DCB2A0", "41 6E 6F 53 44 4B 49 6F"); // AnoSDKIoctlOld

// ========== Control ==========
PATCH_LIB("libUE4.so", "0x3C4EE8C", "45 56 45 4E 54 49 44 5F"); // EVENTID_TPLAN_ENVCONTROLACTOR_READY
PATCH_LIB("libUE4.so", "0x3C4FBBC", "41 69 72 43 6F 6E 74 72"); // AirControlOffSpeed
PATCH_LIB("libUE4.so", "0x3C50B24", "62 43 6F 6E 74 72 6F 6C"); // bControlByMaxShowDis
PATCH_LIB("libUE4.so", "0x3C50FD8", "53 72 63 43 6F 6E 74 72"); // SrcController
PATCH_LIB("libUE4.so", "0x3C51F7C", "41 69 72 43 6F 6E 74 72"); // AirControlLimitConfig

// ========== Sleep ==========
PATCH_LIB("libUE4.so", "0x2DCABE4", "73 6C 65 65 70 00 73 72"); // sleep
PATCH_LIB("libUE4.so", "0x3D31AA4", "57 68 65 65 6C 65 64 56"); // WheeledVehicleLowSpeedSleepSetup
PATCH_LIB("libUE4.so", "0x3DB7098", "53 6C 65 65 70 41 6E 67"); // SleepAngularThreshold
PATCH_LIB("libUE4.so", "0x3E58004", "53 6C 65 65 70 44 61 6D"); // SleepDamping
PATCH_LIB("libUE4.so", "0x3ECFCE4", "50 65 74 49 73 53 6C 65"); // PetIsSleeping

// ========== Time ==========
PATCH_LIB("libUE4.so", "0x2DCCE88", "75 74 69 6D 65 00 77 61"); // utime
PATCH_LIB("libUE4.so", "0x2DCCEA8", "67 6D 74 69 6D 65 5F 72"); // gmtime_r
PATCH_LIB("libUE4.so", "0x2DCE008", "5F 5A 4E 53 74 31 33 72"); // _ZNSt13runtime_errorD1Ev
PATCH_LIB("libUE4.so", "0x2DCE190", "5F 5A 54 49 53 74 31 33"); // _ZTISt13runtime_error
PATCH_LIB("libUE4.so", "0x2DCE5C4", "67 6D 74 69 6D 65 00 74"); // gmtime

// ========== Ban ==========
PATCH_LIB("libUE4.so", "0x3C7D35C", "42 61 6E 6E 65 72 53 74"); // BannerStaticComp
PATCH_LIB("libUE4.so", "0x3C80624", "62 49 73 50 6C 61 63 65"); // bIsPlaceInSubAnimInstace
PATCH_LIB("libUE4.so", "0x3C89028", "62 41 6E 69 6D 54 72 65"); // bAnimTreeInitialised
PATCH_LIB("libUE4.so", "0x3C9A7E0", "4D 6F 76 65 42 41 6E 69"); // MoveBAnim_Combine
PATCH_LIB("libUE4.so", "0x3CCA82C", "48 69 64 65 41 64 42 61"); // HideAdBanner

// ========== FIX ==========
PATCH_LIB("libUE4.so", "0x3C59B18", "44 6F 77 6E 46 69 78 46"); // DownFixForSecondPoint
PATCH_LIB("libUE4.so", "0x3C5EFC8", "6E 6F 72 6D 61 6C 69 7A"); // normalizing the relation prefix
PATCH_LIB("libUE4.so", "0x3C61120", "69 6E 76 61 6C 69 64 20"); // invalid fixed64 value at offset %d
PATCH_LIB("libUE4.so", "0x3C66C48", "46 69 78 48 65 61 64 53"); // FixHeadSpeed
PATCH_LIB("libUE4.so", "0x3C882B0", "49 6E 50 72 65 66 69 78"); // InPrefix

// ========== aService ==========
PATCH_LIB("libUE4.so", "0x3D0E80C", "44 3A 5C 52 65 6C 65 61"); // D:\Release4.3.0\AS\Survive\Plugins\resetcore-unreal\CommonLib\Source\CommonLib\Private\Services\LuaService.cpp

// ========== aConfig ==========
PATCH_LIB("libUE4.so", "0x2DCAC94", "41 43 6F 6E 66 69 67 75"); // AConfiguration_getKeysHidden
PATCH_LIB("libUE4.so", "0x2DCACCC", "41 43 6F 6E 66 69 67 75"); // AConfiguration_getMcc
PATCH_LIB("libUE4.so", "0x2DCACF8", "41 43 6F 6E 66 69 67 75"); // AConfiguration_getNavHidden
PATCH_LIB("libUE4.so", "0x2DCAD14", "41 43 6F 6E 66 69 67 75"); // AConfiguration_getNavigation
PATCH_LIB("libUE4.so", "0x2DCAD6C", "41 43 6F 6E 66 69 67 75"); // AConfiguration_getScreenSize

// ========== text ==========
PATCH_LIB("libUE4.so", "0x2DCC084", "5F 5A 4E 31 32 67 63 6C"); // _ZN12gcloud_voice18IGCloudVoiceNotify15OnTextTranslateENS_23GCloudVoiceCompleteCodeENS_18SpeechLanguageTypeEPKcS2_S4_
PATCH_LIB("libUE4.so", "0x2DCD228", "65 67 6C 43 72 65 61 74"); // eglCreateContext
PATCH_LIB("libUE4.so", "0x2DCD268", "65 67 6C 44 65 73 74 72"); // eglDestroyContext
PATCH_LIB("libUE4.so", "0x2DCD4D8", "67 6C 44 65 6C 65 74 65"); // glDeleteTextures
PATCH_LIB("libUE4.so", "0x2DCD584", "67 6C 46 72 61 6D 65 62"); // glFramebufferTexture2D

// ========== rodata ==========
PATCH_LIB("libUE4.so", "0xE49B614", "2E 72 6F 64 61 74 61 00"); // .rodata
