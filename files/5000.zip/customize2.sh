# ************************************************
#    WELCOME TO SARHAN ROOT - AUTO INSTALLER
# ************************************************
ui_print "****************************************"
ui_print "       SARHAN ROOT CUSTOM MODULE        "
ui_print "****************************************"
ui_print "- Developer: Sarhan"
ui_print "- Telegram: @SarhanHassan1"
ui_print "- WhatsApp: +201142996667"
ui_print "****************************************"

# --- المرحلة 1: تثبيت التطبيق ---
ui_print "- Stage 1: Installing HMA Application..."
APK_PATH="$MODPATH/app/HMA.apk"

if [ -f "$APK_PATH" ]; then
    # تشغيل التثبيت في الخلفية لضمان عدم توقف السكريبت الأساسي
    (pm install "$APK_PATH") > /dev/null 2>&1 &
    ui_print "[+] HMA App installation triggered."
else
    ui_print "[!] Error: HMA.apk not found."
fi

# --- المرحلة 2: تحميل وتثبيت المديولات ---
MOD_URLS=(
    "https://github.com/Dr-TSNG/ZygiskNext/releases/download/v1.2.9.1/Zygisk-Next-1.2.9.1-534-b8e7e21-release.zip"
    "https://github.com/5ec1cff/TrickyStore/releases/download/1.4.1/Tricky-Store-v1.4.1-245-72b2e84-release.zip"
    "https://github.com/KOWX712/Tricky-Addon-Update-Target-List/releases/download/v4.3/TrickyAddonModule-v4.3.zip"
    "https://github.com/LSPosed/LSPosed.github.io/releases/download/shamiko-414/Shamiko-v1.2.5-414-release.zip"
    "https://github.com/JingMatrix/Vector/releases/download/v2.0/Vector-v2.0-3021-Release.zip"
    "https://github.com/sarhan00/status.txt/releases/download/V1.0/HMA-OSS-ZYGISK-oss-161-zygisk-1777152037-release.1.zip"
    "https://github.com/sarhan00/Strong-Integrity-Fix/releases/download/v1.1/PlayIntegrityFix-Strong.Integrity.-v10.0.24.zip"
)

ui_print "- Stage 2: Downloading Extra Modules..."
if ping -c 1 8.8.8.8 > /dev/null 2>&1; then
    for URL in "${MOD_URLS[@]}"; do
        FILE_NAME=$(basename "$URL")
        ui_print "  > Downloading: $FILE_NAME"
        curl -L "$URL" -o "$TMPDIR/$FILE_NAME"
        if [ -f "$TMPDIR/$FILE_NAME" ]; then
            ui_print "  > Installing: $FILE_NAME"
            # تشغيل التثبيت في الخلفية كأنه سكريبت فرعي
            if [ "$KSU" = "true" ]; then
                (ksu module install "$TMPDIR/$FILE_NAME") > /dev/null 2>&1 &
            else
                (magisk --install-module "$TMPDIR/$FILE_NAME") > /dev/null 2>&1 &
            fi
        fi
    done
else
    ui_print "[!] No Internet: Skipping online modules."
fi

# --- المرحلة النهائية (الحل المقتبس من مديول PIF) ---
ui_print "- Finalizing permissions..."

# تنظيف أي ملفات مؤقتة قد تعيق التثبيت
rm -rf $TMPDIR/*.zip

# ضبط الصلاحيات بشكل إجباري وشامل للمجلد
set_perm_recursive $MODPATH 0 0 0755 0644

ui_print "****************************************"
ui_print "       INSTALLATION SUCCESSFUL!         "
ui_print "       Please reboot your device.       "
ui_print "****************************************"

# أهم سطرين لضمان ظهور كلمة Done باللون الأخضر
true
exit 0
