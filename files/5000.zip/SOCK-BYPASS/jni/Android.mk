LOCAL_PATH := $(call my-dir)
MAIN_LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE    := unrealhax

# إعدادات التحويل البرمجي
LOCAL_CFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w
LOCAL_CFLAGS += -fno-rtti -fno-exceptions -fpermissive

LOCAL_CPPFLAGS := -Wno-error=format-security -fvisibility=hidden -ffunction-sections -fdata-sections -w -Werror -s -std=c++17
LOCAL_CPPFLAGS += -Wno-error=c++11-narrowing -fms-extensions -fno-rtti -fno-exceptions -fpermissive

LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all, -llog

LOCAL_ARM_MODE := arm

# ✅ إضافة مسارات الـ Include
LOCAL_C_INCLUDES := $(MAIN_LOCAL_PATH) \
                    $(MAIN_LOCAL_PATH)/INCLUDE \
                    $(MAIN_LOCAL_PATH)/KittyMemory

# ✅ إضافة ملفات المصدر (بما في ذلك KittyMemory)
LOCAL_SRC_FILES := multi.cpp \
                   KittyMemory/KittyMemory.cpp \
                   KittyMemory/MemoryPatch.cpp

# ✅ إضافة المكتبات المطلوبة
LOCAL_LDLIBS := -llog -landroid -lGLESv2 -ldl -pthread

include $(BUILD_EXECUTABLE)