#include "KittyMemory.h"
#include <fstream>
#include <sstream>
#include <cstring>
#include <dlfcn.h>
#include <android/log.h>
#include <errno.h>

#define LOG_TAG "KittyMemory"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace KittyMemory {

MemoryMap getLibraryMap(const std::string& libName) {
    MemoryMap result = {0, 0, 0, "", false};
    
    FILE* fp = fopen("/proc/self/maps", "rt");
    if (!fp) return result;
    
    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        uintptr_t start, end;
        char perms[10];
        char path[256] = {0};
        
        if (sscanf(line, "%lx-%lx %9s %*s %*s %*s %255s", &start, &end, perms, path) >= 3) {
            std::string pathStr(path);
            if (pathStr.find(libName) != std::string::npos) {
                result.startAddr = start;
                result.endAddr = end;
                result.length = end - start;
                result.path = pathStr;
                result.isValid = true;
                break;
            }
        }
    }
    fclose(fp);
    return result;
}

int memRead(void* address, void* buffer, size_t size) {
    if (address == nullptr || buffer == nullptr || size == 0) {
        return INVALID_ADDRESS;
    }
    
    // قراءة الذاكرة
    memcpy(buffer, address, size);
    return SUCCESS;
}

int memWrite(void* address, const void* buffer, size_t size) {
    if (address == nullptr || buffer == nullptr || size == 0) {
        return INVALID_ADDRESS;
    }
    
    // تغيير صلاحيات الذاكرة
    long pageSize = sysconf(_SC_PAGESIZE);
    if (pageSize <= 0) pageSize = 4096;
    
    uintptr_t pageStart = (uintptr_t)address & ~(pageSize - 1);
    size_t totalLength = ((uintptr_t)address - pageStart) + size;
    
    // محاولة تغيير الصلاحيات
    if (mprotect((void*)pageStart, totalLength, PROT_READ | PROT_WRITE | PROT_EXEC) != 0) {
        // إذا فشل mprotect، حاول مرة أخرى
        if (mprotect((void*)pageStart, totalLength, PROT_READ | PROT_WRITE) != 0) {
            return PERMISSION_DENIED;
        }
    }
    
    // كتابة الذاكرة
    memcpy(address, buffer, size);
    
    // تحديث الكاش
    __builtin___clear_cache((char*)address, (char*)address + size);
    
    return SUCCESS;
}

bool isAddressValid(uintptr_t address) {
    if (address == 0) return false;
    
    uint8_t test;
    if (memRead((void*)address, &test, 1) == SUCCESS) {
        return true;
    }
    return false;
}

bool setProtection(uintptr_t address, size_t size, int prot) {
    long pageSize = sysconf(_SC_PAGESIZE);
    if (pageSize <= 0) pageSize = 4096;
    
    uintptr_t pageStart = address & ~(pageSize - 1);
    size_t totalLength = (address - pageStart) + size;
    
    return mprotect((void*)pageStart, totalLength, prot) == 0;
}

} // namespace KittyMemory