#include "MemoryPatch.h"
#include <cstring>
#include <android/log.h>

#define LOG_TAG "MemoryPatch"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace KittyMemory {

Patch MemoryPatch::createPatch(uintptr_t targetAddress, const void* patchData, size_t size, const std::string& name) {
    Patch patch;
    patch.targetAddress = targetAddress;
    patch.size = size;
    patch.isApplied = false;
    patch.name = name;
    
    // قراءة البايتات الأصلية
    patch.originalBytes.resize(size);
    if (KittyMemory::memRead((void*)targetAddress, patch.originalBytes.data(), size) != KittyMemory::SUCCESS) {
        patch.originalBytes.clear();
        return patch;
    }
    
    // تخزين البايتات الجديدة
    patch.patchBytes.resize(size);
    memcpy(patch.patchBytes.data(), patchData, size);
    
    return patch;
}

bool MemoryPatch::applyPatch(Patch& patch) {
    if (patch.size == 0 || patch.patchBytes.empty()) {
        return false;
    }
    
    if (KittyMemory::memWrite((void*)patch.targetAddress, patch.patchBytes.data(), patch.size) == KittyMemory::SUCCESS) {
        patch.isApplied = true;
        return true;
    }
    return false;
}

bool MemoryPatch::restorePatch(Patch& patch) {
    if (patch.size == 0 || patch.originalBytes.empty()) {
        return false;
    }
    
    if (KittyMemory::memWrite((void*)patch.targetAddress, patch.originalBytes.data(), patch.size) == KittyMemory::SUCCESS) {
        patch.isApplied = false;
        return true;
    }
    return false;
}

bool MemoryPatch::isPatched(const Patch& patch) {
    return patch.isApplied;
}

bool MemoryPatch::memWrite(void* address, const void* buffer, size_t size) {
    return KittyMemory::memWrite(address, buffer, size) == KittyMemory::SUCCESS;
}

bool MemoryPatch::memRead(void* address, void* buffer, size_t size) {
    return KittyMemory::memRead(address, buffer, size) == KittyMemory::SUCCESS;
}

} // namespace KittyMemory