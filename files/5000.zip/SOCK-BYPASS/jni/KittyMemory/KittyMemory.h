#pragma once

#include <string>
#include <vector>
#include <cstdint>
#include <unistd.h>
#include <sys/mman.h>

namespace KittyMemory {

// تعريف الثوابت
const int SUCCESS = 0;
const int FAILED = -1;
const int INVALID_ADDRESS = -2;
const int PERMISSION_DENIED = -3;
const int NOT_FOUND = -4;

struct MemoryMap {
    uintptr_t startAddr;
    uintptr_t endAddr;
    size_t length;
    std::string path;
    bool isValid;
};

// دوال KittyMemory
MemoryMap getLibraryMap(const std::string& libName);
int memRead(void* address, void* buffer, size_t size);
int memWrite(void* address, const void* buffer, size_t size);
bool isAddressValid(uintptr_t address);
bool setProtection(uintptr_t address, size_t size, int prot);

} // namespace KittyMemory