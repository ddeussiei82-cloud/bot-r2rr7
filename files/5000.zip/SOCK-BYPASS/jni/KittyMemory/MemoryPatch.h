#pragma once

#include <vector>
#include <string>
#include <cstdint>
#include "KittyMemory.h"

namespace KittyMemory {

struct Patch {
    uintptr_t targetAddress;
    std::vector<uint8_t> originalBytes;
    std::vector<uint8_t> patchBytes;
    size_t size;
    bool isApplied;
    std::string name;
};

class MemoryPatch {
public:
    static Patch createPatch(uintptr_t targetAddress, const void* patchData, size_t size, const std::string& name = "");
    static bool applyPatch(Patch& patch);
    static bool restorePatch(Patch& patch);
    static bool isPatched(const Patch& patch);
    
    // دوال مساعدة (مباشرة)
    static bool memWrite(void* address, const void* buffer, size_t size);
    static bool memRead(void* address, void* buffer, size_t size);
};

} // namespace KittyMemory