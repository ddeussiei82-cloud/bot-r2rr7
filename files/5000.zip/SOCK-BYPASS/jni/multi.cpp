#include "INCLUDE/support.h"
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <thread>
#include <string.h>
#include <vector>
#include <map>
#include <pthread.h>
#include <jni.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <ctime>
#include <atomic>
#include <mutex>
#include <sstream>
#include <errno.h>
#include <android/log.h>
#include "oxorany.cpp"

// ==================== إعدادات السجل ====================
#define LOG_TAG "ProAntiCheat"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

typedef int8_t BYTE;
int handle = -1;
int32_t gGMemFD = -1;
static bool isAntiCheatDisabled = false;
static std::atomic<bool> monitoring_active(true);
static std::atomic<bool> loop_active(true);
static std::mutex monitor_mutex;
static int current_pid = 0;
static time_t last_full_scan = 0;
static const int FULL_SCAN_INTERVAL = 60;

// ==================== تخزين الدوال المكتشفة ====================
struct DiscoveredFunction {
    std::string name;
    uintptr_t address;
    uintptr_t offset;
    std::string library;
    time_t discoveredTime;
    bool isDisabled;
};

static std::vector<DiscoveredFunction> discoveredFunctions;
static std::mutex discoveredMutex;

// ==================== ملفات التقارير في Download ====================
std::string DEBUG_LOG_PATH = "/sdcard/Download/debug_log.txt";
std::string ERROR_LOG_PATH = "/sdcard/Download/error_log.txt";

void writeDebugLog(const std::string& msg) {
    std::ofstream debugFile(DEBUG_LOG_PATH, std::ios::app);
    if (debugFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        debugFile << "[" << dt << "] [DEBUG] " << msg << std::endl;
        debugFile.close();
    }
}

void writeErrorLog(const std::string& msg) {
    std::ofstream errorFile(ERROR_LOG_PATH, std::ios::app);
    if (errorFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        errorFile << "[" << dt << "] [ERROR] " << msg << std::endl;
        errorFile.close();
    }
}

// ==================== دوال التسجيل والتقارير ====================

void writeLog(const std::string& msg) {
    std::ofstream logFile("/data/local/tmp/anticheat_log.txt", std::ios::app);
    if (logFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        logFile << "[" << dt << "] " << msg << std::endl;
        logFile.close();
    }
    writeDebugLog(msg);
}

void writeReport(const std::string& status, const std::string& details) {
    std::ofstream reportFile("/sdcard/Download/anticheat_report.txt", std::ios::app);
    if (reportFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        reportFile << "[" << dt << "] STATUS: " << status << " | " << details << std::endl;
        reportFile.close();
    }
    writeDebugLog("REPORT: " + status + " | " + details);
}

void writeFinalReport(const std::string& content) {
    std::ofstream finalReport("/sdcard/Download/anticheat_final_report.txt", std::ios::trunc);
    if (finalReport.is_open()) {
        finalReport << content;
        finalReport.close();
    }
}

// ==================== ملف آخر تشغيل ====================
void writeLastRunTime() {
    std::ofstream lastRunFile("/sdcard/Download/last_run.txt", std::ios::trunc);
    if (lastRunFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        lastRunFile << "========================================\n";
        lastRunFile << "آخر تشغيل: " << dt << std::endl;
        lastRunFile << "PID: " << current_pid << std::endl;
        lastRunFile << "الحالة: نشط - يعمل بشكل مستمر\n";
        lastRunFile << "========================================\n";
        lastRunFile.close();
        writeLog("✅ تم كتابة آخر تشغيل في last_run.txt");
    }
}

// ==================== تسجيل الدوال المكتشفة ====================
void logDiscoveredFunction(const std::string& libName, const std::string& funcName, uintptr_t address, uintptr_t baseAddr) {
    std::lock_guard<std::mutex> lock(discoveredMutex);
    
    DiscoveredFunction func;
    func.name = funcName;
    func.address = address;
    func.offset = address - baseAddr;
    func.library = libName;
    func.discoveredTime = time(nullptr);
    func.isDisabled = true;
    
    discoveredFunctions.push_back(func);
    
    std::ofstream discoveredFile("/sdcard/Download/discovered_functions.txt", std::ios::app);
    if (discoveredFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        discoveredFile << "[" << dt << "] ";
        discoveredFile << "المكتبة: " << libName << " | ";
        discoveredFile << "الدالة: " << funcName << " | ";
        discoveredFile << "العنوان: 0x" << std::hex << address << " | ";
        discoveredFile << "الأوفست: 0x" << std::hex << func.offset << std::dec << std::endl;
        discoveredFile.close();
    }
    
    char logMsg[256];
    sprintf(logMsg, "📝 تم تسجيل الدالة: %s في %s (الأوفست: 0x%lx)", 
            funcName.c_str(), libName.c_str(), func.offset);
    writeLog(logMsg);
    writeReport("DISCOVERED", logMsg);
}

// ==================== إظهار إشعار على الشاشة ====================
void showNotification(const std::string& message) {
    __android_log_print(ANDROID_LOG_INFO, "AntiCheat", "✅ %s", message.c_str());
    
    std::ofstream notifyFile("/data/local/tmp/notification.txt", std::ios::app);
    if (notifyFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        notifyFile << "[" << dt << "] ✅ " << message << std::endl;
        notifyFile.close();
    }
    
    std::ofstream toastFile("/sdcard/Download/anticheat_status.txt", std::ios::trunc);
    if (toastFile.is_open()) {
        time_t now = time(nullptr);
        char* dt = ctime(&now);
        dt[strlen(dt) - 1] = '\0';
        toastFile << "[" << dt << "] " << message << std::endl;
        toastFile.close();
    }
    
    std::string cmd = "echo \"✅ " + message + "\" > /dev/null";
    system(cmd.c_str());
}

// ==================== دوال الكشف عن الباكج ====================

long int get_module_base(int pid, const char *module_name) {
    FILE *fp;
    long addr = 0;
    char filename[64];
    char line[1024];
    
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                sscanf(line, "%lx-%*lx %*s %*s %*s %*d", &addr);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}

long int get_module_end(int pid, const char *module_name) {
    FILE *fp;
    long end = 0;
    char filename[64];
    char line[1024];
    
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                sscanf(line, "%*lx-%lx %*s %*s %*s %*d", &end);
                break;
            }
        }
        fclose(fp);
    }
    return end;
}

long int get_module_size(int pid, const char *module_name) {
    long start = get_module_base(pid, module_name);
    long end = get_module_end(pid, module_name);
    return (start && end) ? (end - start) : 0;
}

int getPID(const char *packageName) {
    DIR *dir = opendir("/proc");
    struct dirent *ptr;
    FILE *fp;
    char filepath[256];
    char filetext[128];
    
    if (!dir) return 0;
    
    while ((ptr = readdir(dir)) != NULL) {
        if (ptr->d_type != DT_DIR) continue;
        snprintf(filepath, sizeof(filepath), "/proc/%s/cmdline", ptr->d_name);
        fp = fopen(filepath, "r");
        if (fp) {
            fgets(filetext, sizeof(filetext), fp);
            fclose(fp);
            if (strcmp(filetext, packageName) == 0) {
                closedir(dir);
                return atoi(ptr->d_name);
            }
        }
    }
    closedir(dir);
    return 0;
}

// ==================== دوال الكتابة بنفس طريقة الأيم بوت ====================

bool writeMemoryIovec(uintptr_t address, const void* buffer, size_t size) {
    char logMsg[256];
    sprintf(logMsg, "✍️ [IOVEC] كتابة في 0x%lx, الحجم: %zu", address, size);
    writeDebugLog(logMsg);
    
    if (address == 0 || buffer == nullptr || size == 0) {
        writeErrorLog("❌ [IOVEC] معاملات غير صالحة");
        return false;
    }
    
    // استخدام syscall(SYS_pwritev) مثل الأيم بوت
    struct iovec iov = {(void*)buffer, size};
    ssize_t written = syscall(SYS_pwritev, gGMemFD, &iov, 1, address);
    if (written == (ssize_t)size) {
        writeDebugLog("✅ [IOVEC] الكتابة نجحت عبر SYS_pwritev");
        return true;
    }
    
    // استخدام pwrite64 كبديل
    ssize_t written2 = pwrite64(handle, buffer, size, address);
    if (written2 == (ssize_t)size) {
        writeDebugLog("✅ [IOVEC] الكتابة نجحت عبر pwrite64");
        return true;
    }
    
    // استخدام ptrace كحل أخير
    if (current_pid > 0) {
        writeDebugLog("🔧 [IOVEC] محاولة ptrace...");
        if (ptrace(PTRACE_ATTACH, current_pid, NULL, NULL) == 0) {
            usleep(100000);
            const uint8_t* bytes = (const uint8_t*)buffer;
            bool success = true;
            for (size_t i = 0; i < size; i++) {
                if (ptrace(PTRACE_POKETEXT, current_pid, (void*)(address + i), bytes[i]) != 0) {
                    success = false;
                    break;
                }
            }
            ptrace(PTRACE_DETACH, current_pid, NULL, NULL);
            if (success) {
                writeDebugLog("✅ [IOVEC] الكتابة نجحت عبر ptrace");
                return true;
            }
        }
    }
    
    writeErrorLog("❌ [IOVEC] فشل الكتابة");
    return false;
}

bool writeRET(uintptr_t address) {
    uint32_t ret = 0xD65F03C0;
    return writeMemoryIovec(address, &ret, sizeof(ret));
}

bool writeNOPs(uintptr_t targetAddress, size_t count) {
    std::vector<uint32_t> nops(count, 0xD503201F);
    return writeMemoryIovec(targetAddress, nops.data(), nops.size() * sizeof(uint32_t));
}

bool patchFunctionReturnZero(uintptr_t functionAddress) {
    uint32_t arm64Patch[] = {0xD2800000, 0xD65F03C0};
    return writeMemoryIovec(functionAddress, arm64Patch, sizeof(arm64Patch));
}

bool writeMemoryFast(uintptr_t address, const void* buffer, size_t size) {
    return writeMemoryIovec(address, buffer, size);
}

bool writeMemoryWithRetry(uintptr_t address, const void* buffer, size_t size, int maxRetries = 2) {
    for (int i = 0; i < maxRetries; i++) {
        if (writeMemoryIovec(address, buffer, size)) {
            return true;
        }
        usleep(50000);
    }
    return false;
}

// ==================== فحص الذاكرة الدفعي ====================

size_t scanAndNullifyBatch(uintptr_t startAddr, size_t rangeSize, const std::vector<std::string>& targets) {
    char logMsg[256];
    sprintf(logMsg, "🔍 [scanAndNullifyBatch] بدء الفحص - العنوان: 0x%lx, الحجم: %zu, عدد النصوص: %zu", 
            startAddr, rangeSize, targets.size());
    writeDebugLog(logMsg);
    writeLog("🔍 بدء فحص الذاكرة...");
    
    std::lock_guard<std::mutex> lock(monitor_mutex);
    size_t totalMatches = 0;
    
    if (startAddr == 0) {
        writeErrorLog("❌ [scanAndNullifyBatch] العنوان 0! توقف");
        return 0;
    }
    
    if (rangeSize == 0 || rangeSize > 0x10000000) {
        sprintf(logMsg, "❌ [scanAndNullifyBatch] حجم غير معقول: %zu", rangeSize);
        writeErrorLog(logMsg);
        return 0;
    }
    
    // قراءة الذاكرة باستخدام pread64
    std::vector<uint8_t> buffer(rangeSize);
    ssize_t bytesRead = pread64(handle, buffer.data(), rangeSize, startAddr);
    if (bytesRead <= 0) {
        sprintf(logMsg, "❌ [scanAndNullifyBatch] فشل قراءة الذاكرة: %s", strerror(errno));
        writeErrorLog(logMsg);
        writeReport("ERROR", "فشل قراءة الذاكرة");
        return 0;
    }
    
    sprintf(logMsg, "✅ [scanAndNullifyBatch] تم قراءة %zu بايت", bytesRead);
    writeDebugLog(logMsg);
    writeLog("✅ تم قراءة الذاكرة بنجاح");
    
    for (const auto& target : targets) {
        size_t strLen = target.length();
        if (strLen == 0 || strLen > rangeSize) continue;
        
        for (size_t i = 0; i <= (size_t)bytesRead - strLen; ++i) {
            if (memcmp(buffer.data() + i, target.c_str(), strLen) == 0) {
                uintptr_t targetAddr = startAddr + i;
                std::vector<uint8_t> zeros(strLen, 0);
                
                if (writeMemoryIovec(targetAddr, zeros.data(), strLen)) {
                    totalMatches++;
                    char logMsgFound[256];
                    sprintf(logMsgFound, "✅ تم تصفير '%s' عند 0x%lx", target.c_str(), targetAddr);
                    writeLog(logMsgFound);
                    writeDebugLog(logMsgFound);
                    i += strLen - 1;
                } else {
                    char logMsgFailed[256];
                    sprintf(logMsgFailed, "❌ فشل تصفير '%s' عند 0x%lx", target.c_str(), targetAddr);
                    writeErrorLog(logMsgFailed);
                }
            }
        }
    }
    
    sprintf(logMsg, "📊 [scanAndNullifyBatch] اكتمل الفحص: تم تصفير %zu نص", totalMatches);
    writeDebugLog(logMsg);
    writeLog("📊 اكتمل فحص النصوص: " + std::to_string(totalMatches) + " نص تم تصفيرها");
    
    if (totalMatches == 0) {
        writeLog("⚠️ لم يتم العثور على أي نص من القائمة في الذاكرة");
        writeReport("WARNING", "لم يتم العثور على نصوص حساسة في الذاكرة");
    }
    
    return totalMatches;
}

// ==================== قوائم الاستهداف ====================

static const std::vector<std::string> TARGET_ANTI_CHEAT_LIBS = {
    "libanogs.so",
    "libUE4.so",
    "libgcloud.so",
    "libTDataMaster.so",
    "libace.so",
    "libtersafe.so",
    "libsec.so"
};

static const std::vector<std::string> FILE_CHECK_STRINGS = {
    "/system/", "/sbin/", "/su", "magisk", "frida", "xposed", "crc", "detection", "memory",
    "/data/local/", "TWRP", "init.rc", "com.tencent", "antiroot", "inject", "hook", "bypass", 
    "/proc/self/status", "TracePid", "checkFile", "isRooted","memcpy", "memset", "mem", "anti",
    "/system/bin/sh", "which su", "mount | grep", "SuperSU", "report",
    "libanort", "libanogs", "libUE4", "substrate", "cydia", "rootkit",
    "_system_property_read", "_system_property_find_nth", "stack_chk_fail", "kchk_guard",
    "memcpy", "memset", "snprintf", "pthread_attr_destroy", "pthread_attr_init",
    "pthread_create", "strncpy", "memmove", "mincore", "pthread_mutex_trylock",
    "pthread_mutexattr_init", "pthread_mutexattr_settype", "strcat", "strdup",
    "strncmp", "pthread_mutexattr_destroy", "pthread_attr_setdetachstate", "strnlen",
    "strcpy", "strtoul", "ftell", "fwrite", "sprintf", "lseek", "nanosleep", "sendto",
    "ferror", "fprintf", "fputc", "strtod", "_android_log_print", "mem", "strcoll",
    "strncat", "strpbrk", "strtok", "strxfrm", "_aeabi_memmove4", "gnu_Unwind_Findexidx",
    "Monitor", "CoreReport", "TdmReport", "Tss", "Cheat", "Report", "Server",
    "VacInstancedTasks", "Path", "com.ace.gamesafe4", "cheat_open_id", "traceback",
    "seccp", "aLog", "aScreenshot", "aScreenshotAbor", "aSc_report", "aShell_report",
    "AnoSDKDelReportData3", "AnoSDKFree", "AnoSDKIoctlOld", "AnoSDKOnPause",
    "AnoSDKOnResume", "AnoSDKGetReportData", "AnoSDKOnRecvSignature", "JNI_OnLoad",
    "ANO", "AnoSDKGetReportData2", "AnoSDKForExport", "AnoSDKInit",
    "AnoSDKSetUserInfoWithLicense", "AnoSDKOnRecvData", "AnoSDKRegistInfoListener",
    "AnoSDKSetUserInfo", "__cxa_atexit", "imp.free", "imp.pthread_key_create",
    "imp.pthread_getspecific", "AnoSDKIoctl", "imp.openat", "imp.__aeabi_memclr",
    "imp.__aeabi_memmove", "imp.__aeabi_memclr8", "AnoSDKDelReportData", "imp.chmod",
    "imp.__aeabi_memclr4", "imp.__aeabi_memcpy", "imp.__cxa_finalize",
    "imp.__aeabi_memcpy4", "imp.raise", "imp.atoi", "imp.getpid", "imp.malloc",
    "imp.sleep", "imp.sscanf", "imp.strlen", "imp.time", "imp.close", "imp.sysconf",
    "imp.__aeabi_memset", "imp.__errno", "imp.cacheflush", "AnoSDK", "AntiCheat",
    "AntiDebug", "AntiHook", "ptrace", "IsDebuggerPresent", "CheckIntegrity",
    "MemoryScanner", "GetModuleHandle", "__aeabi_memclr", "__aeabi_memcpy",
    "__cxa_finalize", "GetLocalPlayer", "GetEntityList", "GetActorList",
    "WorldToScreen", "GetBoneMatrix", "ProcessEvent", "GetControlRotation",
    "SetActorLocation", "GetViewPoint", "recv", "send", "Encrypt", "Decrypt",
    "Packet", "Login", "Auth", "OnUpdate", "OnTick", "hook", "trampoline",
    "dump", "memory", "seccp", "log_", "debug_", "key", "secret", "token",
    "version", "build", "HookDetected", "Unhooking", "DetectHook",
    "VerifySignature", "SignatureMismatch", "IntegrityCheckFailed",
    "SecurityAlert", "CheatDetection", "MemoryIntegrity", "DobbyHook",
    "MinHook", "MHook", "Xposed", "FridaDetected", "RootDetected",
    "__android_log_assert", "_Unwind_RaiseException", "__cxa_throw",
    "__cxa_rethrow", "__cxa_begin_catch", "__cxa_end_catch", "Abort",
    "ExitProcess", "__stack_chk_fail", "__stack_chk_guard", "fatal_error",
    "CriticalError", "MemoryProtection", "VirtualProtect", "mprotect",
    "mmap", "munmap", "is_mapped", "ReadProcessMemory", "WriteProcessMemory",
    "AccessViolation", "SegmentationFault", "BadAddress", "AES_decrypt",
    "AES_encrypt", "XOR_encrypt", "XOR_decrypt", "SSL_read", "SSL_write",
    "recvfrom", "getpeername", "socket_", "connect_", "bind_", "DebugBridge",
    "IsDebuggerAttached", "GetThreadContext", "SetThreadContext",
    "SignalHandler", "SigSegv", "SigTrap", "Breakpoint", "__builtin_trap",
    "Projectile", "ProjectileMovement", "ProjectileClass", "LaunchProjectile",
    "FireBullet", "SpawnProjectile", "CalcTrajectory", "PredictProjectilePath",
    "TraceBullet", "LineTraceSingle", "LineTraceMulti", "Raycast", "HitResult",
    "ImpactPoint", "AdjustBullet", "CurveBullet", "HomingBullet", "TargetHoming",
    "RedirectBullet", "BulletVelocity", "BulletGravity", "ReportData",
    "SendReport", "UploadLog", "UploadData", "PostData", "SendToServer",
    "ClientReport", "CrashReport", "GameLog", "ExceptionReport", "DumpReport",
    "VerifyFile", "FileHash", "CheckCRC", "CheckSignature", "TamperDetect",
    "MemoryCheck", "CodeVerify", "SignCheck", "SecurityCheck", "HookCheck",
    "ScanMemory", "FindPattern", "CheckMemory", "AnalyzeProcess", "ModuleCheck",
    "CheckMap"
};

// ==================== قائمة الدوال المستهدفة (مثل الأيم بوت) ====================

static const std::vector<std::string> TARGET_FUNCTIONS = {
    "AnoSDKInit", "AnoSDKInitEx", "AnoSDKSetUserInfo", "AnoSDKSetUserInfoWithLicense",
    "AnoSDKGetReportData", "AnoSDKGetReportData2", "AnoSDKGetReportData3",
    "AnoSDKGetReportData4", "AnoSDKDelReportData", "AnoSDKDelReportData3",
    "AnoSDKDelReportData4", "AnoSDKIoctl", "AnoSDKIoctlOld", "AnoSDKOnPause",
    "AnoSDKOnResume", "AnoSDKOnRecvData", "AnoSDKRegistInfoListener",
    "CheckIntegrity", "VerifySignature", "ValidateMemory", "ScanForHooks",
    "DetectModification", "CheckMap", "AnalyzeProcess", "MemoryScanner",
    "AntiDebug", "AntiHook", "AntiPatch", "AntiTamper", "AntiDump",
    "IsDebuggerPresent", "IsEmulator", "IsRooted", "IsHooked",
    "SendReport", "UploadData", "PostData", "EncryptData", "DecryptData",
    "ConnectServer", "VerifyToken", "AuthenticateUser"
};

// ==================== دوال تعطيل مكافحة الغش ====================

bool neutralizeAntiCheatModule(long int baseAddr, size_t size) {
    char logMsg[256];
    sprintf(logMsg, "===== بدء تحييد مكتبة الحماية في العنوان: 0x%lx =====", baseAddr);
    writeLog(logMsg);
    writeDebugLog(logMsg);
    writeReport("PROCESSING", "تحييد المكتبة 0x" + std::to_string(baseAddr));
    
    bool success = true;
    
    if (baseAddr == 0) {
        writeErrorLog("❌ neutralizeAntiCheatModule: العنوان 0");
        return false;
    }
    
    if (size == 0 || size > 0x10000000) {
        sprintf(logMsg, "❌ neutralizeAntiCheatModule: حجم غير معقول: %zu", size);
        writeErrorLog(logMsg);
        return false;
    }
    
    writeDebugLog("🔍 بدء scanAndNullifyBatch");
    size_t totalMatches = scanAndNullifyBatch(baseAddr, size, FILE_CHECK_STRINGS);
    writeDebugLog("✅ scanAndNullifyBatch اكتمل: " + std::to_string(totalMatches) + " نص تم تصفيرها");
    
    if (totalMatches > 0) {
        sprintf(logMsg, "✅ تم تصفير %zu نص حساس (دفعة واحدة)", totalMatches);
        writeLog(logMsg);
        writeReport("SUCCESS", logMsg);
        writeDebugLog(logMsg);
    } else {
        writeLog("⚠️ لم يتم تصفير أي نص");
        writeDebugLog("⚠️ scanAndNullifyBatch لم يجد أي نصوص");
    }
    
    writeDebugLog("🔧 محاولة كتابة RET في العنوان الأساسي");
    bool retSuccess = false;
    for (int attempt = 0; attempt < 3; attempt++) {
        if (writeRET(baseAddr)) {
            retSuccess = true;
            writeLog("✅ تم تعطيل العنوان الأساسي للمكتبة بنجاح (RET).");
            writeReport("SUCCESS", "RET written at base address");
            writeDebugLog("✅ RET written at 0x" + std::to_string(baseAddr));
            break;
        }
        usleep(50000);
    }
    
    if (!retSuccess) {
        writeLog("❌ فشل تعطيل العنوان الأساسي!");
        writeReport("FAILED", "Failed to write RET at base");
        writeErrorLog("❌ فشل كتابة RET في 0x" + std::to_string(baseAddr));
        success = false;
    }
    
    writeDebugLog("🔧 محاولة كتابة NOPs");
    if (writeNOPs(baseAddr, 4)) {
        writeLog("✅ تم كتابة NOPs في بداية المكتبة");
        writeDebugLog("✅ NOPs written at 0x" + std::to_string(baseAddr));
    } else {
        writeDebugLog("⚠️ فشل كتابة NOPs");
    }
    
    writeDebugLog("✅ neutralizeAntiCheatModule اكتمل: " + std::string(success ? "نجاح" : "فشل"));
    return success;
}

// ==================== دوال تعطيل الدوال الفردية (مثل الأيم بوت) ====================

uintptr_t getFunctionAddress(const std::string& libName, const std::string& funcName) {
    char logMsg[256];
    sprintf(logMsg, "🔍 [getFunctionAddress] البحث عن %s في %s", funcName.c_str(), libName.c_str());
    writeDebugLog(logMsg);
    
    void* handle = nullptr;
    
    // محاولة 1: dlopen باسم المكتبة فقط
    handle = dlopen(libName.c_str(), RTLD_NOW);
    if (!handle) {
        // محاولة 2: المسار الكامل في system
        std::string fullPath = "/system/lib64/" + libName;
        handle = dlopen(fullPath.c_str(), RTLD_NOW);
        if (!handle) {
            // محاولة 3: مسار اللعبة
            fullPath = "/data/app/com.tencent.ig/lib/arm64/" + libName;
            handle = dlopen(fullPath.c_str(), RTLD_NOW);
            if (!handle) {
                // محاولة 4: استخدام RTLD_DEFAULT
                void* addr = dlsym(RTLD_DEFAULT, funcName.c_str());
                if (addr) {
                    sprintf(logMsg, "✅ [getFunctionAddress] تم العثور على %s عبر RTLD_DEFAULT في 0x%lx", 
                            funcName.c_str(), (uintptr_t)addr);
                    writeDebugLog(logMsg);
                    return (uintptr_t)addr;
                }
                
                // محاولة 5: مسار آخر
                fullPath = "/data/app/com.tencent.ig/lib/arm64-v8a/" + libName;
                handle = dlopen(fullPath.c_str(), RTLD_NOW);
                if (!handle) {
                    sprintf(logMsg, "❌ [getFunctionAddress] فشل العثور على %s", funcName.c_str());
                    writeErrorLog(logMsg);
                    return 0;
                }
            }
        }
    }
    
    void* addr = dlsym(handle, funcName.c_str());
    if (!addr) {
        sprintf(logMsg, "❌ [getFunctionAddress] dlsym فشل لـ %s", funcName.c_str());
        writeErrorLog(logMsg);
        dlclose(handle);
        return 0;
    }
    
    sprintf(logMsg, "✅ [getFunctionAddress] تم العثور على %s في 0x%lx", funcName.c_str(), (uintptr_t)addr);
    writeDebugLog(logMsg);
    return (uintptr_t)addr;
}

bool isFunctionDisabled(uintptr_t addr) {
    if (addr == 0) return false;
    uint32_t first_insn = 0;
    ssize_t bytesRead = pread64(handle, &first_insn, sizeof(first_insn), addr);
    if (bytesRead != sizeof(first_insn)) return false;
    return (first_insn == 0xD65F03C0 || first_insn == 0xD2800000);
}

bool disableSingleFunctionAdvanced(const std::string& libName, const std::string& funcName) {
    char logMsg[256];
    sprintf(logMsg, "🔧 [disableSingleFunctionAdvanced] تعطيل %s في %s", funcName.c_str(), libName.c_str());
    writeDebugLog(logMsg);
    
    uintptr_t addr = getFunctionAddress(libName, funcName);
    
    if (addr == 0) {
        sprintf(logMsg, "❌ دالة %s غير موجودة في %s", funcName.c_str(), libName.c_str());
        writeLog(logMsg);
        writeErrorLog(logMsg);
        return false;
    }
    
    long int baseAddr = get_module_base(current_pid, libName.c_str());
    if (baseAddr == 0) {
        FILE* fp = fopen("/proc/self/maps", "rt");
        if (fp) {
            char line[512];
            while (fgets(line, sizeof(line), fp)) {
                uintptr_t start, end;
                char perms[10];
                char path[256] = {0};
                if (sscanf(line, "%lx-%lx %9s %*s %*s %*s %255s", &start, &end, perms, path) >= 3) {
                    std::string pathStr(path);
                    if (pathStr.find(libName) != std::string::npos) {
                        baseAddr = start;
                        break;
                    }
                }
            }
            fclose(fp);
        }
    }
    
    if (baseAddr != 0) {
        bool found = false;
        for (const auto& f : discoveredFunctions) {
            if (f.name == funcName && f.library == libName) {
                found = true;
                break;
            }
        }
        if (!found) {
            logDiscoveredFunction(libName, funcName, addr, baseAddr);
        }
    }
    
    if (isFunctionDisabled(addr)) {
        sprintf(logMsg, "✅ الدالة %s مُعطَّلة مسبقاً", funcName.c_str());
        writeLog(logMsg);
        writeDebugLog(logMsg);
        return true;
    }
    
    sprintf(logMsg, "▶ تعطيل الدالة %s في العنوان: 0x%lx", funcName.c_str(), addr);
    writeLog(logMsg);
    writeDebugLog(logMsg);
    
    bool result = patchFunctionReturnZero(addr);
    if (result) {
        sprintf(logMsg, "✅ تم تعطيل الدالة %s بنجاح", funcName.c_str());
        writeLog(logMsg);
        writeReport("SUCCESS", logMsg);
        writeDebugLog(logMsg);
    } else {
        sprintf(logMsg, "❌ فشل تعطيل الدالة %s", funcName.c_str());
        writeLog(logMsg);
        writeReport("FAILED", logMsg);
        writeErrorLog(logMsg);
    }
    return result;
}

// ==================== دالة الفحص الكامل ====================

void performFullScan() {
    char logMsg[256];
    time_t now = time(nullptr);
    struct tm* timeinfo = localtime(&now);
    char timeStr[64];
    strftime(timeStr, sizeof(timeStr), "%H:%M:%S", timeinfo);
    
    sprintf(logMsg, "🔄 [%s] بدء الفحص الدوري الكامل (كل دقيقة)", timeStr);
    writeLog(logMsg);
    writeReport("SCAN", logMsg);
    LOGI("%s", logMsg);
    writeDebugLog(logMsg);
    
    showNotification("🔄 جاري فحص الحماية...");
    
    int pid = getPID("com.tencent.ig");
    if (pid == 0) {
        pid = getPID("com.pubg.krmobile");
    }
    if (pid == 0) {
        pid = getPID("com.rekoo.pubgm");
    }
    if (pid == 0) {
        pid = getPID("com.vng.pubgmobile");
    }
    if (pid == 0) {
        pid = getPID("com.pubg.imobile");
    }
    
    if (pid == 0) {
        writeLog("❌ اللعبة غير موجودة! انتظار إعادة التشغيل...");
        writeReport("ERROR", "Game process not found");
        showNotification("❌ اللعبة غير موجودة");
        writeDebugLog("❌ Game process not found");
        return;
    }
    
    writeDebugLog("✅ Game found: PID " + std::to_string(pid));
    
    if (current_pid != pid) {
        sprintf(logMsg, "🔄 تم اكتشاف PID جديد: %d (كان %d)", pid, current_pid);
        writeLog(logMsg);
        writeDebugLog(logMsg);
        current_pid = pid;
        
        if (handle != -1) close(handle);
        if (gGMemFD != -1) close(gGMemFD);
        
        char lj[64];
        sprintf(lj, "/proc/%d/mem", pid);
        handle = open(lj, O_RDWR);
        gGMemFD = open(lj, O_RDWR);
        
        if (handle == -1 || gGMemFD == -1) {
            sprintf(logMsg, "❌ فشل فتح الذاكرة: %s", strerror(errno));
            writeLog(logMsg);
            writeErrorLog(logMsg);
            showNotification("❌ فشل فتح الذاكرة");
            return;
        }
        
        lseek(gGMemFD, 0, SEEK_SET);
        writeLog("✅ تم فتح الذاكرة (handle و gGMemFD)");
        writeDebugLog("✅ Memory opened successfully");
        writeLastRunTime();
    }
    
    std::vector<std::string> libNames = {
        "libanogs.so", "libUE4.so", "libgcloud.so", "libTDataMaster.so"
    };
    
    for (const auto& libName : libNames) {
        long int baseAddr = get_module_base(pid, libName.c_str());
        if (baseAddr != 0) {
            size_t size = get_module_size(pid, libName.c_str());
            if (size > 0) {
                sprintf(logMsg, "✅ تم العثور على %s في 0x%lx (الحجم: %zu)", 
                        libName.c_str(), baseAddr, size);
                writeDebugLog(logMsg);
                writeLog("✅ تم العثور على " + libName);
                neutralizeAntiCheatModule(baseAddr, size);
            }
        } else {
            sprintf(logMsg, "⚠️ %s غير موجود", libName.c_str());
            writeDebugLog(logMsg);
        }
    }
    
    int successCount = 0;
    int failCount = 0;
    writeDebugLog("🔧 بدء تعطيل الدوال...");
    
    std::vector<std::string> criticalFuncs = {
        "AnoSDKInit", "AnoSDKGetReportData", "CheckIntegrity", "JNI_OnLoad"
    };
    
    writeDebugLog("🔧 تعطيل الدوال الحرجة أولاً...");
    for (const auto& func : criticalFuncs) {
        if (disableSingleFunctionAdvanced("libanogs.so", func)) {
            successCount++;
        } else {
            failCount++;
        }
    }
    
    writeDebugLog("🔧 تعطيل باقي الدوال...");
    for (const auto& func : TARGET_FUNCTIONS) {
        if (std::find(criticalFuncs.begin(), criticalFuncs.end(), func) != criticalFuncs.end()) {
            continue;
        }
        if (disableSingleFunctionAdvanced("libanogs.so", func)) {
            successCount++;
        } else if (disableSingleFunctionAdvanced("libUE4.so", func)) {
            successCount++;
        } else {
            failCount++;
        }
    }
    
    sprintf(logMsg, "📊 [%s] نتيجة الفحص: %d نجاح, %d فشل", timeStr, successCount, failCount);
    writeLog(logMsg);
    writeReport("SCAN_RESULT", logMsg);
    writeDebugLog(logMsg);
    
    long int libanogs = get_module_base(pid, "libanogs.so");
    if (libanogs != 0) {
        uint32_t test = 0;
        pread64(handle, &test, sizeof(test), libanogs);
        if (test != 0xD65F03C0) {
            writeLog("⚠️ المكتبة عادت للعمل! إعادة التعطيل الفوري...");
            writeDebugLog("⚠️ Library returned to work, re-disabling...");
            showNotification("⚠️ إعادة تعطيل الحماية...");
            neutralizeAntiCheatModule(libanogs, get_module_size(pid, "libanogs.so"));
        } else {
            writeLog("✅ المكتبة لا زالت معطلة");
            writeDebugLog("✅ Library still disabled");
        }
    }
    
    last_full_scan = now;
    sprintf(logMsg, "✅ [%s] اكتمل الفحص الدوري", timeStr);
    writeLog(logMsg);
    writeReport("SCAN_COMPLETE", logMsg);
    writeDebugLog(logMsg);
    
    showNotification("✅ تم تشغيل الحماية بنجاح");
    writeDebugLog("✅ performFullScan completed successfully");
}

// ==================== خيط المراقبة الدورية ====================

void* monitorThread(void* arg) {
    LOGI("✅ تم بدء خيط المراقبة الدورية.");
    writeLog("▶ تم بدء خيط المراقبة الدورية (كل دقيقة)");
    writeReport("PROCESSING", "Monitoring thread started (every 60 seconds)");
    writeDebugLog("✅ Monitoring thread started");
    
    performFullScan();
    
    int checkCount = 0;
    while (loop_active.load()) {
        sleep(1);
        checkCount++;
        
        if (checkCount >= FULL_SCAN_INTERVAL) {
            checkCount = 0;
            
            int pid = getPID("com.tencent.ig");
            if (pid == 0) {
                pid = getPID("com.pubg.krmobile");
            }
            if (pid == 0) {
                pid = getPID("com.rekoo.pubgm");
            }
            if (pid == 0) {
                pid = getPID("com.vng.pubgmobile");
            }
            if (pid == 0) {
                pid = getPID("com.pubg.imobile");
            }
            
            if (pid != 0) {
                performFullScan();
            } else {
                writeLog("⏳ انتظار تشغيل اللعبة...");
                writeDebugLog("⏳ Waiting for game...");
                showNotification("⏳ انتظار تشغيل اللعبة...");
            }
        }
        
        if (checkCount % 5 == 0 && current_pid != 0) {
            std::vector<std::string> criticalFuncs = {
                "AnoSDKInit", "AnoSDKGetReportData", "CheckIntegrity"
            };
            
            for (const auto& func : criticalFuncs) {
                uintptr_t addr = getFunctionAddress("libanogs.so", func);
                if (addr != 0 && !isFunctionDisabled(addr)) {
                    LOGW("⚠ الدالة %s عادت للعمل، إعادة تعطيلها...", func.c_str());
                    writeLog("⚠ الدالة " + func + " عادت للعمل، إعادة تعطيلها...");
                    writeDebugLog("⚠ Function " + func + " returned, re-disabling...");
                    disableSingleFunctionAdvanced("libanogs.so", func);
                    showNotification("⚠ تم إعادة تعطيل " + func);
                }
            }
        }
    }
    
    LOGI("⏹ تم إيقاف خيط المراقبة.");
    writeLog("▶ تم إيقاف خيط المراقبة");
    writeReport("COMPLETE", "Monitoring thread stopped");
    writeDebugLog("⏹ Monitoring thread stopped");
    return nullptr;
}

void startMonitoring() {
    pthread_t thread;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    
    if (pthread_create(&thread, &attr, monitorThread, nullptr) != 0) {
        LOGE("❌ فشل في إنشاء خيط المراقبة!");
        writeLog("✗ فشل في إنشاء خيط المراقبة");
        writeErrorLog("❌ Failed to create monitoring thread");
        showNotification("❌ فشل تشغيل المراقبة");
    } else {
        LOGI("✅ تم تشغيل خيط المراقبة بنجاح.");
        writeLog("✓ تم تشغيل خيط المراقبة بنجاح (كل دقيقة)");
        writeReport("SUCCESS", "Monitoring thread started (every 60 seconds)");
        writeDebugLog("✅ Monitoring thread created successfully");
        showNotification("✅ تم تشغيل المراقبة (كل دقيقة)");
    }
    pthread_attr_destroy(&attr);
}

void stopMonitoring() {
    loop_active.store(false);
    monitoring_active.store(false);
    LOGI("⏹ تم طلب إيقاف المراقبة.");
    writeLog("▶ تم طلب إيقاف المراقبة");
    writeDebugLog("⏹ Stop monitoring requested");
    showNotification("⏹ تم إيقاف المراقبة");
}
// ==================== خيط حذف التقارير (كل 5 دقائق) ====================

void* cleanerThread(void* arg) {
    writeLog("🗑️ بدء خيط حذف التقارير (كل 5 دقائق)");
    writeDebugLog("🗑️ Cleaner thread started");
    
    while (loop_active.load()) {
        // انتظر 5 دقائق (300 ثانية)
        for (int i = 0; i < 180 && loop_active.load(); i++) {
            sleep(1);
        }
        
        if (!loop_active.load()) break;
        
        // حذف التقارير
        std::vector<std::string> files = {
            "/sdcard/Download/anticheat_report.txt",
            "/sdcard/Download/anticheat_final_report.txt",
            "/sdcard/Download/last_run.txt",
            "/sdcard/Download/anticheat_status.txt",
            "/sdcard/Download/debug_log.txt",
            "/sdcard/Download/error_log.txt",
            "/sdcard/Download/discovered_functions.txt",
            "/data/local/tmp/anticheat_log.txt",
            "/data/local/tmp/notification.txt"
        };
        
        int deleted = 0;
        for (const auto& file : files) {
            if (remove(file.c_str()) == 0) {
                deleted++;
            }
        }
        
        char msg[256];
        sprintf(msg, "🗑️ تم حذف %d تقرير", deleted);
        writeLog(msg);
        writeDebugLog(msg);
    }
    
    writeLog("⏹ توقف خيط حذف التقارير");
    return nullptr;
}
// ==================== الدالة الرئيسية لتعطيل كل شيء ====================

void neutralizeAllAntiCheatModules(int pid) {
    writeLog("========================================");
    writeLog("=== STARTING ANTI-CHEAT DISABLE ===");
    writeLog("========================================");
    writeDebugLog("=== STARTING ANTI-CHEAT DISABLE ===");
    writeReport("START", "Anti-Cheat disabler initialized");
    showNotification("🛡️ بدء تعطيل الحماية...");
    
    current_pid = pid;
    
    std::vector<std::string> libNames = {
        "libanogs.so", "libUE4.so", "libgcloud.so", "libTDataMaster.so"
    };
    
    for (const auto& libName : libNames) {
        long int baseAddr = get_module_base(pid, libName.c_str());
        if (baseAddr != 0) {
            size_t size = get_module_size(pid, libName.c_str());
            if (size > 0) {
                char logMsg[256];
                sprintf(logMsg, "✅ تم العثور على %s في 0x%lx (الحجم: %zu)", 
                        libName.c_str(), baseAddr, size);
                writeLog(logMsg);
                writeDebugLog(logMsg);
                writeReport("PROCESSING", logMsg);
                
                if (neutralizeAntiCheatModule(baseAddr, size)) {
                    sprintf(logMsg, "✅ %s تم تعطيله بنجاح", libName.c_str());
                    writeLog(logMsg);
                    writeDebugLog(logMsg);
                    writeReport("SUCCESS", logMsg);
                }
            }
        } else {
            char logMsg[256];
            sprintf(logMsg, "❌ %s غير موجود", libName.c_str());
            writeLog(logMsg);
            writeDebugLog(logMsg);
            writeReport("FAILED", logMsg);
        }
    }
    
    writeLog("▶ Disabling individual functions...");
    writeReport("PROCESSING", "Disabling target functions");
    writeDebugLog("▶ Disabling individual functions...");
    showNotification("🔧 تعطيل الدوال...");
    
    int successCount = 0;
    int failCount = 0;
    
    std::vector<std::string> criticalFuncs = {
        "AnoSDKInit", "AnoSDKGetReportData", "CheckIntegrity", "JNI_OnLoad"
    };
    
    writeDebugLog("🔧 Disabling critical functions first...");
    for (const auto& func : criticalFuncs) {
        if (disableSingleFunctionAdvanced("libanogs.so", func)) {
            successCount++;
        } else {
            failCount++;
        }
    }
    
    writeDebugLog("🔧 Disabling remaining functions...");
    for (const auto& func : TARGET_FUNCTIONS) {
        if (std::find(criticalFuncs.begin(), criticalFuncs.end(), func) != criticalFuncs.end()) {
            continue;
        }
        if (disableSingleFunctionAdvanced("libanogs.so", func)) {
            successCount++;
        } else if (disableSingleFunctionAdvanced("libUE4.so", func)) {
            successCount++;
        } else {
            failCount++;
        }
    }
    
    char summaryMsg[512];
    sprintf(summaryMsg, "Functions disabled: %d success, %d failed", successCount, failCount);
    writeLog(summaryMsg);
    writeDebugLog(summaryMsg);
    writeReport("SUMMARY", summaryMsg);
    
    startMonitoring();
    
    writeLog("========================================");
    writeLog("=== ANTI-CHEAT DISABLED SUCCESSFULLY ===");
    writeLog("========================================");
    writeDebugLog("=== ANTI-CHEAT DISABLED SUCCESSFULLY ===");
    writeReport("SUCCESS", "All anti-cheat modules and functions have been disabled");
    
    showNotification("✅ تم تعطيل الحماية بنجاح");
    isAntiCheatDisabled = true;
}

// ==================== FEATURE 1: التشغيل التلقائي ====================

void feature1(int pid) {
    writeLog("========================================");
    writeLog("=== FEATURE 1: AUTO ANTI-CHEAT DISABLE ===");
    writeLog("========================================");
    writeDebugLog("=== FEATURE 1 STARTED ===");
    writeReport("FEATURE", "Feature 1 activated - Auto anti-cheat disable");
    showNotification("🔄 بدء التشغيل التلقائي...");
    
    writeLog("▶ Waiting for libraries to load...");
    writeReport("PROCESSING", "Waiting for libanogs.so to load");
    writeDebugLog("▶ Waiting for libanogs.so to load...");
    
    long int libanogs = 0;
    int retryCount = 0;
    int maxRetries = 60;
    
    while (libanogs == 0 && retryCount < maxRetries) {
        sleep(1);
        libanogs = get_module_base(pid, "libanogs.so");
        retryCount++;
        
        if (retryCount % 5 == 0) {
            char logMsg[256];
            sprintf(logMsg, "▶ Waiting for libanogs.so... (%d/%d)", retryCount, maxRetries);
            writeLog(logMsg);
            writeDebugLog(logMsg);
        }
    }
    
    if (libanogs != 0) {
        char logMsg[256];
        sprintf(logMsg, "✅ libanogs.so loaded at 0x%lx", libanogs);
        writeLog(logMsg);
        writeDebugLog(logMsg);
        writeReport("PROCESSING", "libanogs.so detected, applying patches");
        showNotification("✅ تم اكتشاف libanogs.so");
    } else {
        writeLog("❌ libanogs.so not loaded after timeout");
        writeDebugLog("❌ libanogs.so not loaded after timeout");
        writeReport("FAILED", "libanogs.so not loaded after timeout");
        showNotification("❌ فشل تحميل libanogs.so");
        return;
    }
    
    neutralizeAllAntiCheatModules(pid);
    
    writeLog("✅ Anti-Cheat disabled successfully.");
    writeDebugLog("✅ Anti-Cheat disabled successfully.");
    writeReport("SUCCESS", "Feature 1 completed successfully");
    showNotification("✅ تم تعطيل مكافحة الغش");
    
    std::ostringstream finalReport;
    time_t now = time(nullptr);
    char* dt = ctime(&now);
    dt[strlen(dt) - 1] = '\0';
    finalReport << "========================================\n";
    finalReport << "ANTI-CHEAT DISABLE FINAL REPORT\n";
    finalReport << "Time: " << dt << "\n";
    finalReport << "Status: SUCCESS ✅\n";
    finalReport << "Package: com.tencent.ig\n";
    finalReport << "PID: " << pid << "\n";
    finalReport << "libanogs.so: 0x" << std::hex << libanogs << "\n";
    finalReport << "Monitoring: ACTIVE (Every 60 seconds) 🔄\n";
    finalReport << "Anti-Cheat: DISABLED 🚫\n";
    finalReport << "========================================\n";
    writeFinalReport(finalReport.str());
    writeDebugLog("✅ Final report written");
}

// ==================== الدالة الرئيسية ====================

int main(int argc, char **argv) {
    writeDebugLog("========================================");
    writeDebugLog("=== PRO ANTI-CHEAT DISABLER v9.0 DEBUG ===");
    writeDebugLog("========================================");
    writeDebugLog("✅ Program started");
    
    static bool alreadyRunning = false;
    if (alreadyRunning) {
        printf("⚠️ البرنامج يعمل بالفعل!\n");
        writeLog("⚠️ محاولة تشغيل متكررة - تم الرفض");
        writeDebugLog("⚠️ Duplicate run attempt blocked");
        return 0;
    }
    alreadyRunning = true;
    writeDebugLog("✅ First instance confirmed");
    
    printf("\n");
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║   PRO ANTI-CHEAT DISABLER v9.0                     ║\n");
    printf("║   🔄 Auto-Scan Every 60 Seconds                   ║\n");
    printf("║   📝 Function Discovery & Logging                 ║\n");
    printf("║   📁 Reports: /sdcard/Download/                  ║\n");
    printf("║   📋 Debug Log: debug_log.txt                    ║\n");
    printf("║   ❌ Error Log: error_log.txt                    ║\n");
    printf("║   ⚡ Using IOVEC method (same as aimbot)        ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n");
    printf("\n");
    
    writeLog("=== PRO ANTI-CHEAT DISABLER v9.0 STARTED ===");
    writeLog("🔄 Auto-scan every 60 seconds");
    writeLog("📝 Function discovery enabled");
    writeLog("📋 Debug logging enabled");
    writeLog("⚡ Using IOVEC write method");
    writeReport("INFO", "PRO Anti-Cheat Disabler v9.0 started (IOVEC method)");
    writeDebugLog("✅ Initialization complete");
    
    showNotification("🛡️ تشغيل برنامج الحماية");
    
    int ipid = getPID("com.tencent.ig");
    const char* runningPackage = nullptr;
    writeDebugLog("🔍 Searching for game process...");
    
    if (ipid != 0) {
        runningPackage = "com.tencent.ig";
    } else if ((ipid = getPID("com.pubg.krmobile")) != 0) {
        runningPackage = "com.pubg.krmobile";
    } else if ((ipid = getPID("com.rekoo.pubgm")) != 0) {
        runningPackage = "com.rekoo.pubgm";
    } else if ((ipid = getPID("com.vng.pubgmobile")) != 0) {
        runningPackage = "com.vng.pubgmobile";
    } else if ((ipid = getPID("com.pubg.imobile")) != 0) {
        runningPackage = "com.pubg.imobile";
    }

    if (ipid == 0) {
        printf("❌ اللعبة غير موجودة!\n");
        printf("💡 تأكد من تشغيل PUBG Mobile!\n");
        writeLog("✗ فشل العثور على اللعبة");
        writeDebugLog("❌ Game process not found");
        writeReport("FAILED", "Game process not found");
        showNotification("❌ فشل العثور على اللعبة");
        return 1;
    }
    
    char logMsg[256];
    sprintf(logMsg, "✅ اللعبة: %s (PID: %d)", runningPackage, ipid);
    printf("%s\n", logMsg);
    writeLog(logMsg);
    writeDebugLog(logMsg);
    writeReport("INFO", logMsg);
    showNotification("✅ تم العثور على اللعبة");
    
    // فتح الذاكرة بطريقتين (مثل الأيم بوت)
    char lj[64];
    sprintf(lj, "/proc/%d/mem", ipid);
    writeDebugLog("🔧 Opening memory: " + std::string(lj));
    
    handle = open(lj, O_RDWR);
    gGMemFD = open(lj, O_RDWR);
    
    if (handle == -1 || gGMemFD == -1) {
        printf("❌ فشل فتح الذاكرة: %s\n", strerror(errno));
        sprintf(logMsg, "✗ فشل فتح الذاكرة: %s", strerror(errno));
        writeLog(logMsg);
        writeDebugLog(logMsg);
        writeReport("FAILED", "Failed to open /proc/mem");
        showNotification("❌ فشل فتح الذاكرة");
        return 1;
    }
    
    lseek(gGMemFD, 0, SEEK_SET);
    
    current_pid = ipid;
    printf("✅ تم فتح الذاكرة (IOVEC ready)\n");
    writeLog("✓ تم فتح الذاكرة (IOVEC ready)");
    writeDebugLog("✅ Memory opened successfully (handle: " + std::to_string(handle) + ", gGMemFD: " + std::to_string(gGMemFD) + ")");
    writeReport("SUCCESS", "Memory access granted (IOVEC)");
    showNotification("✅ تم فتح الذاكرة");
    
    writeLastRunTime();
    writeDebugLog("✅ Last run time written");
    showNotification("📝 تم تسجيل وقت التشغيل");
    
    printf("\n▶ بدء التعطيل...\n");
    writeLog("▶ بدء التعطيل");
    writeDebugLog("▶ Starting disable process...");
    
    performFullScan();
    
    startMonitoring();


// ✅ أضف هذا السطر هنا
    pthread_t cleaner_thread;
    pthread_create(&cleaner_thread, NULL, cleanerThread, NULL);
    printf("\n");
    printf("╔══════════════════════════════════════════════════════╗\n");
    printf("║   ✅ النظام يعمل                                    ║\n");
    printf("║   🔄 فحص كل 60 ثانية                              ║\n");
    printf("║   📝 تسجيل الدوال المكتشفة                        ║\n");
    printf("║   📁 التقارير: /sdcard/Download/                  ║\n");
    printf("║   🕐 آخر تشغيل: last_run.txt                     ║\n");
    printf("║   📝 الدوال: discovered_functions.txt            ║\n");
    printf("║   📋 التصحيح: debug_log.txt                      ║\n");
    printf("║   ❌ الأخطاء: error_log.txt                      ║\n");
    printf("║   ⚡ IOVEC method active                         ║\n");
    printf("╚══════════════════════════════════════════════════════╝\n");
    printf("\n");
    printf("⏳ يعمل... اضغط Ctrl+C للإيقاف\n");
    printf("📁 التقارير في /sdcard/Download/\n");
    printf("📋 سجل التصحيح: debug_log.txt\n");
    printf("❌ سجل الأخطاء: error_log.txt\n");
    printf("\n");
    
    showNotification("✅ تم تشغيل الحماية");
    writeDebugLog("✅ System running, waiting for game...");
    
    while (loop_active.load()) {
        int pid = getPID("com.tencent.ig");
        if (pid == 0) {
            pid = getPID("com.pubg.krmobile");
        }
        if (pid == 0) {
            pid = getPID("com.rekoo.pubgm");
        }
        if (pid == 0) {
            pid = getPID("com.vng.pubgmobile");
        }
        if (pid == 0) {
            pid = getPID("com.pubg.imobile");
        }
        
        if (pid == 0) {
            writeLog("🔄 اللعبة أغلقت! انتظار إعادة التشغيل...");
            writeDebugLog("🔄 Game closed, waiting for restart...");
            showNotification("⏳ انتظار إعادة تشغيل اللعبة...");
            
            while (pid == 0 && loop_active.load()) {
                sleep(5);
                pid = getPID("com.tencent.ig");
                if (pid == 0) {
                    pid = getPID("com.pubg.krmobile");
                }
                if (pid == 0) {
                    pid = getPID("com.rekoo.pubgm");
                }
                if (pid == 0) {
                    pid = getPID("com.vng.pubgmobile");
                }
                if (pid == 0) {
                    pid = getPID("com.pubg.imobile");
                }
            }
            
            if (pid != 0 && loop_active.load()) {
                writeLog("🔄 تم إعادة تشغيل اللعبة! PID: " + std::to_string(pid));
                writeDebugLog("🔄 Game restarted with PID: " + std::to_string(pid));
                showNotification("🔄 تم إعادة تشغيل اللعبة");
                current_pid = pid;
                performFullScan();
            }
        }
        
        sleep(10);
    }
    
    close(handle);
    close(gGMemFD);
    writeLog("▶ تم الإيقاف");
    writeDebugLog("▶ Program stopped");
    writeReport("COMPLETE", "All operations finished");
    showNotification("⏹ توقف البرنامج");
    
    return 0;
}