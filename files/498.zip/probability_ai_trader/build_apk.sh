#!/bin/bash

echo "=========================================="
echo "  بناء تطبيق Probability AI Trader"
echo "=========================================="

# التحقق من Flutter
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter غير مثبت!"
    echo "حمّله من: https://flutter.dev/docs/get-started/install"
    exit 1
fi

echo "✅ Flutter موجود"
flutter --version

# تثبيت الحزم
echo ""
echo "📦 تثبيت الحزم..."
flutter pub get

# بناء APK
echo ""
echo "🔨 بناء APK..."
flutter build apk --release

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ تم البناء بنجاح!"
    echo "📱 ملف APK موجود في:"
    echo "   build/app/outputs/flutter-apk/app-release.apk"
    echo ""
    echo "📋 لنسخ الملف إلى سطح المكتب:"
    echo "   cp build/app/outputs/flutter-apk/app-release.apk ~/Desktop/"
else
    echo ""
    echo "❌ فشل البناء!"
    exit 1
fi