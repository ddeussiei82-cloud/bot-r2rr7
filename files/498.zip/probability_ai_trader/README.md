# Probability AI Trader - Android App

تطبيق تداول آلي متقدم يعمل على أندرويد فقط.

## ✨ الميزات

- ✅ عرض إشارات التداول (BUY/SELL/HOLD)
- ✅ شارتات تفاعلية للأسعار
- ✅ نسب الاحتمالات (Bull/Bear)
- ✅ دعم EURUSD و GBPUSD
- ✅ جميع الفريمات (1m, 3m, 5m, 15m, 30m, 1h, 4h, 1D)
- ✅ وضع تجريبي (بدون Backend)

## 🚀 التشغيل السريع

### 1. تثبيت Flutter
```bash
# تأكد من تثبيت Flutter
flutter doctor
```

### 2. بناء التطبيق
```bash
# على Linux/Mac
chmod +x build_apk.sh
./build_apk.sh

# على Windows
flutter pub get
flutter build apk --release
```

### 3. تثبيت على جهازك
```bash
# طريقة 1: عبر adb
adb install build/app/outputs/flutter-apk/app-release.apk

# طريقة 2: انقل الملف إلى جهازك وثبّته يدوياً
```

## 🔧 الاتصال بالـ Backend

في `lib/config.dart`:
```dart
static const bool useMockData = false; // غيّر إلى false

// ثم غيّر IP:
static const String baseUrl = 'http://YOUR_IP:8000';
```

## 📱 الفريمات المدعومة

| الفريم | الوصف |
|--------|-------|
| 1m | دقيقة واحدة |
| 3m | 3 دقائق |
| 5m | 5 دقائق |
| 15m | 15 دقيقة |
| 30m | 30 دقيقة |
| 1h | ساعة |
| 4h | 4 ساعات |
| 1D | يوم |

## 📊 العملات المدعومة

- EURUSD
- GBPUSD

## 🛠️ البنية التقنية

- **Flutter**: إطار العمل
- **fl_chart**: للشارتات
- **percent_indicator**: لمقاييس الاحتمالات
- **http**: للاتصال بالـ API
- **Material 3**: للتصميم

## 📄 الترخيص

MIT License