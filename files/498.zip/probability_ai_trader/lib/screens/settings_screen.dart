import 'package:flutter/material.dart';
import '../config.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildSection('معلومات التطبيق', [
            _buildInfoTile('الإصدار', '1.0.0'),
            _buildInfoTile('الوضع', AppConfig.useMockData ? 'تجريبي' : 'مباشر'),
            _buildInfoTile('العملات', AppConfig.symbols.join(', ')),
            _buildInfoTile('الفريمات', AppConfig.timeframes.join(', ')),
          ]),
          const SizedBox(height: 16),
          _buildSection('الاتصال', [
            _buildInfoTile('الخادم', AppConfig.baseUrl),
            _buildInfoTile('WebSocket', AppConfig.wsUrl),
          ]),
          const SizedBox(height: 16),
          _buildSection('حول المشروع', [
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Probability AI Trader'),
              subtitle: Text('نظام تداول يعتمد على الذكاء الاصطناعي'),
            ),
          ]),
        ],
      ),
    );
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(
            title,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        Card(
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _buildInfoTile(String label, String value) {
    return ListTile(
      title: Text(label),
      subtitle: Text(value, style: const TextStyle(color: Colors.blueGrey)),
    );
  }
}