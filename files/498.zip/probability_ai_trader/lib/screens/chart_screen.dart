import 'package:flutter/material.dart';
import '../config.dart';
import '../models/market_data.dart';
import '../models/signal.dart';
import '../services/api_service.dart';
import '../services/mock_service.dart';
import '../widgets/candlestick_chart.dart';
import '../widgets/probability_gauge.dart';

class ChartScreen extends StatefulWidget {
  final String symbol;
  final String timeframe;

  const ChartScreen({
    Key? key,
    required this.symbol,
    required this.timeframe,
  }) : super(key: key);

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  final ApiService _apiService = ApiService();
  final MockService _mockService = MockService();
  MarketData? _marketData;
  Signal? _signal;
  bool _isLoading = true;
  String? _error;
  late String _selectedTimeframe;

  @override
  void initState() {
    super.initState();
    _selectedTimeframe = widget.timeframe;
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      await Future.delayed(const Duration(milliseconds: 300));
      
      final marketData = AppConfig.useMockData
          ? _mockService.getMarketData(widget.symbol, _selectedTimeframe)
          : await _apiService.getMarketData(widget.symbol, _selectedTimeframe);
      
      final signal = AppConfig.useMockData
          ? _mockService.getSignal(widget.symbol, _selectedTimeframe)
          : await _apiService.getSignal(widget.symbol, _selectedTimeframe);

      setState(() {
        _marketData = marketData;
        _signal = signal;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.symbol),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline, size: 64, color: Colors.red[400]),
            const SizedBox(height: 16),
            Text(_error!, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _loadData, child: const Text('إعادة المحاولة')),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      child: Column(
        children: [
          // Timeframe Selector
          Container(
            height: 60,
            color: Colors.grey[100],
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              itemCount: AppConfig.timeframes.length,
              itemBuilder: (context, index) {
                final tf = AppConfig.timeframes[index];
                final isSelected = tf == _selectedTimeframe;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(tf, style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: isSelected ? Colors.white : Colors.black87,
                    )),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() => _selectedTimeframe = tf);
                        _loadData();
                      }
                    },
                    selectedColor: Colors.blueGrey,
                    backgroundColor: Colors.white,
                  ),
                );
              },
            ),
          ),

          // Signal Badge
          if (_signal != null)
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _getSignalColor(_signal!.signal).withOpacity(0.2),
                    _getSignalColor(_signal!.signal).withOpacity(0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _getSignalColor(_signal!.signal), width: 2),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(_signal!.signalEmoji, style: const TextStyle(fontSize: 48)),
                  const SizedBox(width: 20),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _signal!.signal,
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.bold,
                          color: _getSignalColor(_signal!.signal),
                        ),
                      ),
                      Text(
                        'الثقة: ${_signal!.confidence.toStringAsFixed(1)}%',
                        style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                      ),
                    ],
                  ),
                ],
              ),
            ),

          // Probability Gauge
          if (_signal != null)
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: ProbabilityGauge(
                  bullProbability: _signal!.bullProbability,
                  bearProbability: _signal!.bearProbability,
                  symbol: _signal!.symbol,
                ),
              ),
            ),

          // Chart
          if (_marketData != null)
            Card(
              margin: const EdgeInsets.all(16),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        'الرسم البياني - ${_marketData!.timeframe}',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    ),
                    CandlestickChart(
                      candles: _marketData!.candles,
                      symbol: _marketData!.symbol,
                    ),
                  ],
                ),
              ),
            ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Color _getSignalColor(String signal) {
    switch (signal) {
      case 'BUY': return Colors.green;
      case 'SELL': return Colors.red;
      default: return Colors.grey;
    }
  }
}