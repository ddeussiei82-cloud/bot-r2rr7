class MarketData {
  final String symbol;
  final String timeframe;
  final List<Candle> candles;
  final DateTime lastUpdate;

  MarketData({
    required this.symbol,
    required this.timeframe,
    required this.candles,
    required this.lastUpdate,
  });

  factory MarketData.fromJson(Map<String, dynamic> json) {
    return MarketData(
      symbol: json['symbol'],
      timeframe: json['timeframe'],
      candles: (json['candles'] as List)
          .map((c) => Candle.fromJson(c))
          .toList(),
      lastUpdate: DateTime.parse(json['last_update']),
    );
  }
}

class Candle {
  final DateTime time;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  Candle({
    required this.time,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
  });

  factory Candle.fromJson(Map<String, dynamic> json) {
    return Candle(
      time: DateTime.parse(json['time']),
      open: (json['open'] as num).toDouble(),
      high: (json['high'] as num).toDouble(),
      low: (json['low'] as num).toDouble(),
      close: (json['close'] as num).toDouble(),
      volume: (json['volume'] as num).toDouble(),
    );
  }

  bool get isBullish => close > open;
}