class Signal {
  final String symbol;
  final String timeframe;
  final String signal;
  final double bullProbability;
  final double bearProbability;
  final double confidence;
  final DateTime timestamp;

  Signal({
    required this.symbol,
    required this.timeframe,
    required this.signal,
    required this.bullProbability,
    required this.bearProbability,
    required this.confidence,
    required this.timestamp,
  });

  factory Signal.fromJson(Map<String, dynamic> json) {
    return Signal(
      symbol: json['symbol'],
      timeframe: json['timeframe'],
      signal: json['signal'],
      bullProbability: (json['bull_probability'] as num).toDouble(),
      bearProbability: (json['bear_probability'] as num).toDouble(),
      confidence: (json['confidence'] as num).toDouble(),
      timestamp: DateTime.parse(json['timestamp']),
    );
  }

  String get signalEmoji {
    switch (signal) {
      case 'BUY': return '🟢';
      case 'SELL': return '🔴';
      default: return '⚪';
    }
  }
}