class AppConfig {
  // Android Emulator
  static const String baseUrl = 'http://10.0.2.2:8000';
  static const String wsUrl = 'ws://10.0.2.2:8000/ws/signals';
  
  // للجهاز الحقيقي، غيّر إلى IP الكمبيوتر
  // static const String baseUrl = 'http://192.168.1.100:8000';
  // static const String wsUrl = 'ws://192.168.1.100:8000/ws/signals';
  
  static const List<String> symbols = ['EURUSD', 'GBPUSD'];
  static const List<String> timeframes = ['1m', '3m', '5m', '15m', '30m', '1h', '4h', '1D'];
  
  static const bool useMockData = true; // ضع false للاتصال بالـ Backend الحقيقي
}