import 'dart:math';
import '../models/market_data.dart';
import '../models/signal.dart';

class MockService {
  final Random _random = Random();
  
  final Map<String, double> _basePrices = {
    'EURUSD': 1.0850,
    'GBPUSD': 1.2650,
  };

  MarketData getMarketData(String symbol, String timeframe) {
    final basePrice = _basePrices[symbol] ?? 1.0;
    final candles = <Candle>[];
    final now = DateTime.now();
    
    Duration interval;
    switch (timeframe) {
      case '1m': interval = const Duration(minutes: 1); break;
      case '3m': interval = const Duration(minutes: 3); break;
      case '5m': interval = const Duration(minutes: 5); break;
      case '15m': interval = const Duration(minutes: 15); break;
      case '30m': interval = const Duration(minutes: 30); break;
      case '1h': interval = const Duration(hours: 1); break;
      case '4h': interval = const Duration(hours: 4); break;
      case '1D': interval = const Duration(days: 1); break;
      default: interval = const Duration(hours: 1);
    }

    double currentPrice = basePrice;
    for (int i = 199; i >= 0; i--) {
      final time = now.subtract(interval * i);
      final change = (_random.nextDouble() - 0.5) * 0.002;
      final open = currentPrice;
      final close = currentPrice + change;
      final high = [open, close].reduce(max) + _random.nextDouble() * 0.001;
      final low = [open, close].reduce(min) - _random.nextDouble() * 0.001;
      
      candles.add(Candle(
        time: time,
        open: open,
        high: high,
        low: low,
        close: close,
        volume: (_random.nextDouble() * 1000 + 100).toDouble(),
      ));
      
      currentPrice = close;
    }

    return MarketData(
      symbol: symbol,
      timeframe: timeframe,
      candles: candles,
      lastUpdate: now,
    );
  }

  Signal getSignal(String symbol, String timeframe) {
    final bullProb = 30 + _random.nextDouble() * 40;
    final bearProb = 100 - bullProb;
    final confidence = (bullProb - bearProb).abs();
    
    String signal;
    if (bullProb >= 70) signal = 'BUY';
    else if (bearProb >= 70) signal = 'SELL';
    else signal = 'HOLD';

    return Signal(
      symbol: symbol,
      timeframe: timeframe,
      signal: signal,
      bullProbability: bullProb,
      bearProbability: bearProb,
      confidence: confidence,
      timestamp: DateTime.now(),
    );
  }

  List<Signal> getAllSignals() {
    final signals = <Signal>[];
    for (final symbol in ['EURUSD', 'GBPUSD']) {
      for (final tf in ['1m', '5m', '15m', '1h', '4h']) {
        signals.add(getSignal(symbol, tf));
      }
    }
    return signals;
  }
}