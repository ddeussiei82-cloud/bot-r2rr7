import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config.dart';
import '../models/market_data.dart';
import '../models/signal.dart';

class ApiService {
  Future<MarketData> getMarketData(String symbol, String timeframe) async {
    final response = await http.get(
      Uri.parse('${AppConfig.baseUrl}/api/market/$symbol/$timeframe'),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return MarketData.fromJson(jsonDecode(response.body));
    }
    throw Exception('فشل تحميل البيانات');
  }

  Future<Signal> getSignal(String symbol, String timeframe) async {
    final response = await http.get(
      Uri.parse('${AppConfig.baseUrl}/api/signal/$symbol/$timeframe'),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return Signal.fromJson(jsonDecode(response.body));
    }
    throw Exception('فشل تحميل الإشارة');
  }

  Future<List<Signal>> getAllSignals() async {
    final response = await http.get(
      Uri.parse('${AppConfig.baseUrl}/api/signals'),
    ).timeout(const Duration(seconds: 15));

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((json) => Signal.fromJson(json)).toList();
    }
    throw Exception('فشل تحميل الإشارات');
  }
}