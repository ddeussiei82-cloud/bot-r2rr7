import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

class ProbabilityGauge extends StatelessWidget {
  final double bullProbability;
  final double bearProbability;
  final String symbol;

  const ProbabilityGauge({
    Key? key,
    required this.bullProbability,
    required this.bearProbability,
    required this.symbol,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'نسب الاحتمالات - $symbol',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildGauge(
              percent: bullProbability / 100,
              label: 'صعود',
              value: '${bullProbability.toStringAsFixed(1)}%',
              color: Colors.green,
            ),
            _buildGauge(
              percent: bearProbability / 100,
              label: 'هبوط',
              value: '${bearProbability.toStringAsFixed(1)}%',
              color: Colors.red,
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGauge({
    required double percent,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        CircularPercentIndicator(
          radius: 55.0,
          lineWidth: 10.0,
          percent: percent,
          center: Text(
            value,
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          circularStrokeCap: CircularStrokeCap.round,
          progressColor: color,
          backgroundColor: color.withOpacity(0.2),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: color,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}