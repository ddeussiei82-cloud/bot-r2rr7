import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/market_data.dart';

class CandlestickChart extends StatelessWidget {
  final List<Candle> candles;
  final String symbol;

  const CandlestickChart({
    Key? key,
    required this.candles,
    required this.symbol,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (candles.isEmpty) {
      return const SizedBox(height: 300, child: Center(child: CircularProgressIndicator()));
    }

    final visibleCandles = candles.length > 60 ? candles.sublist(candles.length - 60) : candles;
    final minPrice = visibleCandles.map((c) => c.low).reduce(min);
    final maxPrice = visibleCandles.map((c) => c.high).reduce(max);
    final padding = (maxPrice - minPrice) * 0.1;

    return SizedBox(
      height: 350,
      child: LineChart(
        LineChartData(
          minY: minPrice - padding,
          maxY: maxPrice + padding,
          gridData: FlGridData(
            show: true,
            drawVerticalLine: true,
            getDrawingHorizontalLine: (value) => FlLine(
              color: Colors.grey.withOpacity(0.2),
              strokeWidth: 1,
            ),
            getDrawingVerticalLine: (value) => FlLine(
              color: Colors.grey.withOpacity(0.2),
              strokeWidth: 1,
            ),
          ),
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                interval: 10,
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();
                  if (index >= 0 && index < visibleCandles.length) {
                    final candle = visibleCandles[index];
                    return Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        '${candle.time.hour}:${candle.time.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(fontSize: 9, color: Colors.grey),
                      ),
                    );
                  }
                  return const Text('');
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 60,
                interval: (maxPrice - minPrice) / 5,
                getTitlesWidget: (value, meta) {
                  return Text(
                    value.toStringAsFixed(5),
                    style: const TextStyle(fontSize: 9, color: Colors.grey),
                  );
                },
              ),
            ),
            topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(
            show: true,
            border: Border.all(color: Colors.grey.withOpacity(0.3)),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: visibleCandles.asMap().entries.map((entry) {
                return FlSpot(entry.key.toDouble(), entry.value.close);
              }).toList(),
              isCurved: false,
              color: Colors.blue,
              barWidth: 2,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                color: Colors.blue.withOpacity(0.1),
              ),
            ),
          ],
          lineTouchData: LineTouchData(
            touchTooltipData: LineTouchTooltipData(
              tooltipBgColor: Colors.blueGrey.shade800,
              getTooltipItems: (touchedSpots) {
                return touchedSpots.map((spot) {
                  final candle = visibleCandles[spot.x.toInt()];
                  return LineTooltipItem(
                    '${candle.close.toStringAsFixed(5)}',
                    const TextStyle(color: Colors.white, fontSize: 12),
                  );
                }).toList();
              },
            ),
          ),
        ),
      ),
    );
  }
}

extension _ListExtension<T> on List<T> {
  Iterable<MapEntry<int, T>> asMap() sync* {
    for (var i = 0; i < length; i++) {
      yield MapEntry(i, this[i]);
    }
  }
}

T min<T extends num>(T a, T b) => a < b ? a : b;
T max<T extends num>(T a, T b) => a > b ? a : b;