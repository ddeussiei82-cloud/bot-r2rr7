Exec("/island 5", "✅️ تم تفعيل الحماية ساحه");
Exec("/island 6", "✅️ تم تفعيل الحماية كراش");
Exec("/unrealhax 011", "✅️ تم تفعيل الحماية هووك");
} else {
Exec("/island 5", "✅️ تم تفعيل الحماية ساحه");
Exec("/island 6", "✅️ تم تفعيل الحماية كراش");
Exec("/unrealhax 011", "✅️ تم تفعيل الحماية هووك");
                            
                            
                            
                            
                            
                            .              التعريفات 
                        
MoveAssets(getFilesDir() + "/", "unrealhax");
MoveAssets(getFilesDir() + "/", "island");
MoveAssets(getFilesDir() + "/", "socu64");