#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <stdint.h>
#include <ctype.h>

typedef unsigned char BYTE;

static int handle;
typedef const char* PACKAGENAME;

//---------------------------------------------------
long int get_module_base(int pid, const char *module_name) {
    FILE *fp;
    long addr = 0;
    char filename[32];
    char line[1024];
    
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                char *pch = strtok(line, "-");
                addr = strtoul(pch, NULL, 16);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}

int Tom_qword(long long int addr, long long int value) {
    return pwrite64(handle, &value, 8, addr) == 8 ? 0 : -1;
}

int Tom_dword(long int addr, int value) {
    return pwrite64(handle, &value, 4, addr) == 4 ? 0 : -1;
}

int Tom_float(long int addr, float value) {
    return pwrite64(handle, &value, 4, addr) == 4 ? 0 : -1;
}

int Tom__HEX(long int addr, const BYTE* hex_value, int size) {
    return pwrite64(handle, hex_value, size, addr) == size ? 0 : -1;
}

void TomHex(long int address, const char* hex_value) {
    int hex_len = 0;
    const char *ptr = hex_value;
    while (*ptr) {
        if (isxdigit(*ptr)) hex_len++;
        ptr++;
    }
    hex_len = (hex_len + 1) / 2;
    
    BYTE* hex_bytes = (BYTE*)malloc(hex_len);
    if (!hex_bytes) {
        printf("Memory allocation failed\n");
        return;
    }
    
    int byte_index = 0;
    ptr = hex_value;
    while (*ptr && byte_index < hex_len) {
        if (isxdigit(*ptr)) {
            char byte_str[3] = {0};
            int str_index = 0;
            
            while (*ptr && isxdigit(*ptr) && str_index < 2) {
                byte_str[str_index++] = *ptr++;
            }
            hex_bytes[byte_index++] = (BYTE)strtol(byte_str, NULL, 16);
        } else {
            ptr++;
        }
    }
    
    // الكتابة والتحقق
    if (Tom__HEX(address, hex_bytes, hex_len) == 0) {
        BYTE* read_bytes = (BYTE*)malloc(hex_len);
        if (read_bytes) {
            if (pread64(handle, read_bytes, hex_len, address) == hex_len) {
                if (memcmp(hex_bytes, read_bytes, hex_len) == 0) {
                    printf("✓ Successfully wrote %d bytes to 0x%lx\n", hex_len, address);
                } else {
                    printf("✗ Verification failed at 0x%lx\n", address);
                }
            }
            free(read_bytes);
        }
    } else {
        printf("✗ Write failed at 0x%lx\n", address);
    }
    
    free(hex_bytes);
}

int getPID(PACKAGENAME PackageName) {
    DIR *dir = opendir("/proc");
    if (!dir) return 0;
    
    struct dirent *entry;
    int pid = 0;
    char filepath[256];
    char filetext[128];
    
    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;
            
        if (entry->d_type != DT_DIR)
            continue;
            
        int is_pid = 1;
        for (char *p = entry->d_name; *p; p++) {
            if (!isdigit(*p)) {
                is_pid = 0;
                break;
            }
        }
        if (!is_pid) continue;
        
        sprintf(filepath, "/proc/%s/cmdline", entry->d_name);
        FILE *fp = fopen(filepath, "r");
        if (fp) {
            if (fgets(filetext, sizeof(filetext), fp)) {
                if (strcmp(filetext, PackageName) == 0) {
                    pid = atoi(entry->d_name);
                    fclose(fp);
                    break;
                }
            }
            fclose(fp);
        }
    }
    closedir(dir);
    return pid;
}

typedef struct {
    const char* module_name;
    long offset;
    const char* hex_value;  
} PatchEntry;


const PatchEntry ANOGS_PATCHES[] = {
    {"libanogs.so", 0x395874, "00 00"},
    {"libanogs.so", 0x44E2B8, "00 00"},
    {"libanogs.so", 0x471D88, "00 00"},
    {"libanogs.so", 0x439358, "00 00"},
    {"libanogs.so", 0x2B726C, "00 00"},
    {"libanogs.so", 0x438A64, "00 00"},
    {"libanogs.so", 0x364760, "00 00"},
    {"libanogs.so", 0x479BAC, "00 00"},
    {"libanogs.so", 0x3A0080, "00 00"},
    {"libanogs.so", 0x439964, "00 00"},
    {"libanogs.so", 0x346924, "00 00"},
    {"libanogs.so", 0x34AA80, "00 00"},
    {"libanogs.so", 0x3116E8, "00 00"},
    {"libanogs.so", 0x2ADA88, "00 00"},
    {"libanogs.so", 0x3A2524, "00 00"},
    {"libanogs.so", 0x31C018, "00 00"},
    {"libanogs.so", 0x3275F0, "00 00"},
    {"libanogs.so", 0x1D272C, "00 00"},
    {"libanogs.so", 0x4B3370, "00 00"},
    {"libanogs.so", 0x460DF4, "00 00"},
    {"libanogs.so", 0x395794, "00 00"},
    {"libanogs.so", 0x2D9DD4, "00 00"},
    {"libanogs.so", 0x33CF18, "00 00"},
    {"libanogs.so", 0x3AD988, "00 00"},
    {"libanogs.so", 0x32D9B0, "00 00"},
    {"libanogs.so", 0x4CDFCC, "00 00"},
    {"libanogs.so", 0x4D4FE8, "00 00"},
    {"libanogs.so", 0x3A4320, "00 00"},
    {"libanogs.so", 0x373258, "00 00"},
    {"libanogs.so", 0x30DB84, "00 00"},
    {"libanogs.so", 0x4444FC, "00 00"},
    {"libanogs.so", 0x20280C, "00 00"},
    {"libanogs.so", 0x33BBB8, "00 00"},
    {"libanogs.so", 0x240994, "00 00"},
    {"libanogs.so", 0x34478C, "00 00"},
    {"libanogs.so", 0x3355B4, "00 00"},
    {"libanogs.so", 0x92C36, "00 00"},
    {"libanogs.so", 0x394358, "00 00"},
    {"libanogs.so", 0x2F5904, "00 00"},
    {"libanogs.so", 0x31C02C, "00 00"},
    {"libanogs.so", 0x218340, "00 00"},
};

const PatchEntry TDATA_PATCHES[] = {
    {"libTDataMaster.so", 0x20674, "00 00"},
    {"libTDataMaster.so", 0x251FC8, "00 00"},
    {"libTDataMaster.so", 0x29C524, "00 00"},
    {"libTDataMaster.so", 0x171D9C, "00 00"},
    {"libTDataMaster.so", 0x2C1130, "00 00"},
    {"libTDataMaster.so", 0x1B6778, "00 00"},
    {"libTDataMaster.so", 0x200DA8, "00 00"},
    {"libTDataMaster.so", 0x183C5C, "00 00"},
    {"libTDataMaster.so", 0x1E5CDC, "00 00"},
    {"libTDataMaster.so", 0x2A2C90, "00 00"},
    {"libTDataMaster.so", 0x9FA78, "00 00"},
    {"libTDataMaster.so", 0x1D3160, "00 00"},
    {"libTDataMaster.so", 0x2965FC, "00 00"},
    {"libTDataMaster.so", 0x2AFD98, "00 00"},
    {"libTDataMaster.so", 0xF6508, "00 00"},
    {"libTDataMaster.so", 0x18709C, "00 00"},
    {"libTDataMaster.so", 0x28EB68, "00 00"},
    {"libTDataMaster.so", 0xF605C, "00 00"},
    {"libTDataMaster.so", 0x29CC0C, "00 00"},
    {"libTDataMaster.so", 0x1E8824, "00 00"},
    {"libTDataMaster.so", 0x134374, "00 00"},
    {"libTDataMaster.so", 0x27E3C8, "00 00"},
    {"libTDataMaster.so", 0x2D35D8, "00 00"},
    {"libTDataMaster.so", 0x16DB84, "00 00"},
    {"libTDataMaster.so", 0x14FF90, "00 00"},
    {"libTDataMaster.so", 0xFCABC, "00 00"},
    {"libTDataMaster.so", 0xB86B0, "00 00"},
    {"libTDataMaster.so", 0x201BC8, "00 00"},
    {"libTDataMaster.so", 0x16EB3C, "00 00"},
    {"libTDataMaster.so", 0x2443FC, "00 00"},
    {"libTDataMaster.so", 0x2B9C88, "00 00"},
    {"libTDataMaster.so", 0x158678, "00 00"},
    {"libTDataMaster.so", 0x173BF8, "00 00"},
    {"libTDataMaster.so", 0xA2A80, "00 00"},
    {"libTDataMaster.so", 0xCCCB4, "00 00"},
    {"libTDataMaster.so", 0x1DFD88, "00 00"},
    {"libTDataMaster.so", 0x112970, "00 00"},
    {"libTDataMaster.so", 0x2B3054, "00 00"},
    {"libTDataMaster.so", 0x1ED098, "00 00"},
    {"libTDataMaster.so", 0xB5104, "00 00"},
    {"libTDataMaster.so", 0x2906FC, "00 00"},
}; 

const PatchEntry GCLOUD_PATCHES[] = {
    {"libgcloud.so", 0x10024, "00 00"},
    {"libgcloud.so", 0x2714D4, "00 00"},
    {"libgcloud.so", 0xBE418, "00 00"},
    {"libgcloud.so", 0x3D95F4, "00 00"},
    {"libgcloud.so", 0x203C00, "00 00"},
    {"libgcloud.so", 0x228B0C, "00 00"},
    {"libgcloud.so", 0x31C438, "00 00"},
    {"libgcloud.so", 0x121034, "00 00"},
    {"libgcloud.so", 0x2185B8, "00 00"},
    {"libgcloud.so", 0x11946C, "00 00"},
    {"libgcloud.so", 0x220228, "00 00"},
    {"libgcloud.so", 0x14C6A0, "00 00"},
    {"libgcloud.so", 0xBF834, "00 00"},
    {"libgcloud.so", 0x3E8D10, "00 00"},
    {"libgcloud.so", 0x35D920, "00 00"},
    {"libgcloud.so", 0x3BB094, "00 00"},
    {"libgcloud.so", 0x39C97C, "00 00"},
    {"libgcloud.so", 0xF517C, "00 00"},
    {"libgcloud.so", 0x3A1D8C, "00 00"},
    {"libgcloud.so", 0x457784, "00 00"},
    {"libgcloud.so", 0x2D9EF0, "00 00"},
    {"libgcloud.so", 0xDA7F4, "00 00"},
    {"libgcloud.so", 0x2D95A8, "00 00"},
    {"libgcloud.so", 0x2517A4, "00 00"},
    {"libgcloud.so", 0x1012D0, "00 00"},
    {"libgcloud.so", 0x36F234, "00 00"},
    {"libgcloud.so", 0x1D7BC4, "00 00"},
    {"libgcloud.so", 0x170BC0, "00 00"},
    {"libgcloud.so", 0x4547D8, "00 00"},
    {"libgcloud.so", 0x242294, "00 00"},
    {"libgcloud.so", 0x3313C0, "00 00"},
    {"libgcloud.so", 0x384D3C, "00 00"},
    {"libgcloud.so", 0x265DA4, "00 00"},
    {"libgcloud.so", 0x26AB90, "00 00"},
    {"libgcloud.so", 0x2B3A68, "00 00"},
    {"libgcloud.so", 0x15403C, "00 00"},
    {"libgcloud.so", 0x2B42E8, "00 00"},
    {"libgcloud.so", 0x125B94, "00 00"},
    {"libgcloud.so", 0x1BEB54, "00 00"},
    {"libgcloud.so", 0x233DF4, "00 00"},
    {"libgcloud.so", 0x3CD2D0, "00 00"},
};

const PatchEntry UE4_PATCHES[] = {
    {"libUE4.so", 0x1F4A0, "00 00"},
    {"libUE4.so", 0x99469C4, "00 00"},
    {"libUE4.so", 0xC187CA0, "00 00"},
    {"libUE4.so", 0x5A79B84, "00 00"},
    {"libUE4.so", 0xBB75E2C, "00 00"},
    {"libUE4.so", 0x70E173C, "00 00"},
    {"libUE4.so", 0x7862A90, "00 00"},
    {"libUE4.so", 0xBDE47A4, "00 00"},
    {"libUE4.so", 0xA87BDC8, "00 00"},
    {"libUE4.so", 0xC1198A4, "00 00"},
    {"libUE4.so", 0x63F8CA4, "00 00"},
    {"libUE4.so", 0x7F13F0C, "00 00"},
    {"libUE4.so", 0x70505C4, "00 00"},
    {"libUE4.so", 0xBDCB9A8, "00 00"},
    {"libUE4.so", 0xA6A1F1C, "00 00"},
    {"libUE4.so", 0xB2310E8, "00 00"},
    {"libUE4.so", 0x9F543C0, "00 00"},
    {"libUE4.so", 0xB438EE0, "00 00"},
    {"libUE4.so", 0x9B25260, "00 00"},
    {"libUE4.so", 0x7036D60, "00 00"},
    {"libUE4.so", 0xA81BFE0, "00 00"},
    {"libUE4.so", 0x727BD30, "00 00"},
    {"libUE4.so", 0xB565030, "00 00"},
    {"libUE4.so", 0x9F79604, "00 00"},
    {"libUE4.so", 0xA6E2F7C, "00 00"},
    {"libUE4.so", 0x6847FC4, "00 00"},
    {"libUE4.so", 0x705B898, "00 00"},
    {"libUE4.so", 0xB13495C, "00 00"},
    {"libUE4.so", 0xB23A56C, "00 00"},
    {"libUE4.so", 0x878B378, "00 00"},
    {"libUE4.so", 0xABB3150, "00 00"},
    {"libUE4.so", 0xA76923C, "00 00"},
    {"libUE4.so", 0xBA7B54C, "00 00"},
    {"libUE4.so", 0x6B12838, "00 00"},
    {"libUE4.so", 0xC95582C, "00 00"},
    {"libUE4.so", 0xAFA1134, "00 00"},
    {"libUE4.so", 0xBB76C34, "00 00"},
    {"libUE4.so", 0x61FAE30, "00 00"},
    {"libUE4.so", 0xC368768, "00 00"},
    {"libUE4.so", 0x9844848, "00 00"},
    {"libUE4.so", 0xA6C46E0, "00 00"},
};

void apply_patches(const char* package_name) {
    printf("Searching for process: %s\n", package_name);
    
    int ipid = getPID(package_name);
    if (ipid == 0) {
        printf("Process not found: %s\n", package_name);
        return;
    }
    printf("Found PID: %d\n", ipid);
    
    char mem_path[64];
    sprintf(mem_path, "/proc/%d/mem", ipid);
    handle = open(mem_path, O_RDWR);
    if (handle == -1) {
        printf("Failed to open memory for PID %d\n", ipid);
        return;
    }
    
    // Applying patches for libanogs.so
    printf("Applying libanogs.so patches...\n");
    long int Anogs = get_module_base(ipid, "libanogs.so");
    if (Anogs) {
        printf("libanogs.so base: 0x%lx\n", Anogs);
        for (size_t i = 0; i < sizeof(ANOGS_PATCHES) / sizeof(ANOGS_PATCHES[0]); i++) {
            TomHex(Anogs + ANOGS_PATCHES[i].offset, ANOGS_PATCHES[i].hex_value);
        }
    } else {
        printf("libanogs.so not found\n");
    }

    // Applying patches for libTDataMaster.so
    printf("Applying libTDataMaster.so patches...\n");
    long int TDataMaster = get_module_base(ipid, "libTDataMaster.so");
    if (TDataMaster) {
        printf("libTDataMaster.so base: 0x%lx\n", TDataMaster);
        for (size_t i = 0; i < sizeof(TDATA_PATCHES) / sizeof(TDATA_PATCHES[0]); i++) {
            TomHex(TDataMaster + TDATA_PATCHES[i].offset, TDATA_PATCHES[i].hex_value);
        }
    } else {
        printf("libTDataMaster.so not found\n");
    }

    // Applying patches for libgcloud.so
    printf("Applying libgcloud.so patches...\n");
    long int GCloud = get_module_base(ipid, "libgcloud.so");
    if (GCloud) {
        printf("libgcloud.so base: 0x%lx\n", GCloud);
        for (size_t i = 0; i < sizeof(GCLOUD_PATCHES) / sizeof(GCLOUD_PATCHES[0]); i++) {
            TomHex(GCloud + GCLOUD_PATCHES[i].offset, GCLOUD_PATCHES[i].hex_value);
        }
    } else {
        printf("libgcloud.so not found\n");
    }

    // Applying patches for libUE4.so
    printf("Applying libUE4.so patches...\n");
    long int UE4 = get_module_base(ipid, "libUE4.so");
    if (UE4) {
        printf("libUE4.so base: 0x%lx\n", UE4);
        for (size_t i = 0; i < sizeof(UE4_PATCHES) / sizeof(UE4_PATCHES[0]); i++) {
            TomHex(UE4 + UE4_PATCHES[i].offset, UE4_PATCHES[i].hex_value);
        }
    } else {
        printf("libUE4.so not found\n");
    }

    close(handle);
}

//---------------------------------------------------

int main(int argc, char **argv) {
    printf("=== TOM Memory Patcher ===\n");
    
    apply_patches("com.tencent.ig");  
    apply_patches("com.pubg.krmobile"); 
    
    printf("=== Process Complete ===\n");
    return 0;
}