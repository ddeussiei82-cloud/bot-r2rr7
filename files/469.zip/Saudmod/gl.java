String pkg = "com.tencent.ig";

if (isChecked) {
    Execc("Saudvip" + pkg);
}
