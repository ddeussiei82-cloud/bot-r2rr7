package com.ahmed.internetchecker;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private TextView status, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        Button check = findViewById(R.id.checkButton);

        check.setOnClickListener(v -> checkInternet());
    }

    private void checkInternet() {
        status.setText("⏳ جاري الفحص...");
        result.setText("");

        new Thread(() -> {
            long start = System.currentTimeMillis();
            HttpURLConnection connection = null;

            try {
                URL url = new URL("https://www.google.com/generate_204");
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);
                connection.setRequestMethod("GET");
                connection.setInstanceFollowRedirects(false);

                int code = connection.getResponseCode();
                long latency = System.currentTimeMillis() - start;
                boolean online = (code >= 200 && code < 400);

                runOnUiThread(() -> {
                    if (online) {
                        status.setText("✅ الإنترنت يعمل");
                        result.setText("HTTP: " + code + "\nزمن الاستجابة: " + latency + " ms");
                    } else {
                        status.setText("❌ الاتصال غير متاح");
                        result.setText("HTTP: " + code);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("❌ لا يوجد اتصال");
                    result.setText("تعذر الوصول إلى الإنترنت.");
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        }).start();
    }
}
