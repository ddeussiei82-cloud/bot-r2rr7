#include "INCLUDE/support.h"
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <thread>
#include "oxorany.cpp"

int handle;
typedef int8_t BYTE;

long int get_module_base(int pid, const char *module_name) {
    FILE *fp;
    long addr = 0;
    char filename[64];
    char line[1024];
    
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "r");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                sscanf(line, "%lx-%*lx %*s %*s %*s %*d", &addr);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}

int getPID(const char *packageName) {
    DIR *dir = opendir("/proc");
    struct dirent *ptr;
    FILE *fp;
    char filepath[256];
    char filetext[128];
    
    if (!dir) return 0;
    
    while ((ptr = readdir(dir)) != NULL) {
        if (ptr->d_type != DT_DIR) continue;
        snprintf(filepath, sizeof(filepath), "/proc/%s/cmdline", ptr->d_name);
        fp = fopen(filepath, "r");
        if (fp) {
            fgets(filetext, sizeof(filetext), fp);
            fclose(fp);
            if (strcmp(filetext, packageName) == 0) {
                closedir(dir);
                return atoi(ptr->d_name);
            }
        }
    }
    closedir(dir);
    return 0;
}

long int ReadValue(long int addr) {
    long int var = 0;
    if (handle == -1) {
        printf("Error: Invalid handle\n");
        return 0;
    }
    ssize_t bytesRead = pread64(handle, &var, sizeof(var), addr);
    if (bytesRead != sizeof(var)) {
        printf("Failed to read memory at address 0x%lx\n", addr);
        return 0;
    }
    return var;
}

float WriteAddress_FLOAT(long int addr, float value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int RAYAN_BaseAddress_FLOAT(long int addr, float value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int RAYAN_BaseAddress_DWORD(long int addr, int value) {
    pwrite64(handle, &value, 4, addr);
    return 0;
}

int EDIT_HEX(long int addr, BYTE* hex_value, int size) {
    return pwrite64(handle, hex_value, size, addr);
}

void edithex(long int address, const char* hex_value) {
    int hex_len = strlen(hex_value) / 3 + 1;
    BYTE* hex_bytes = (BYTE*)malloc(hex_len);
    
    for (int i = 0; i < hex_len; i++) {
        unsigned int byte_val;
        sscanf(&hex_value[i * 3], "%2x", &byte_val);
        hex_bytes[i] = (BYTE)byte_val;
    }
    
    EDIT_HEX(address, hex_bytes, hex_len);
    free(hex_bytes);
}

int main(int argc, char **argv) {
/*
pid = getPid("com.ayan.hax");
	if (pid == 0)
	{
	puts("not authorized");
      exit(1);
		}
*/

    if (argc < 2) {
        puts("Usage: ./program <feature_number>");
        return 1;
    }
    
    int Features = atoi(argv[1]);

    // Detect running package
    int ipid = getPID("com.tencent.ig");
    const char* runningPackage = nullptr;
    if (ipid != 0) runningPackage = "com.tencent.ig";
    else if ((ipid = getPID("com.pubg.krmobile")) != 0) runningPackage = "com.pubg.krmobile";
    else if ((ipid = getPID("com.rekoo.pubgm")) != 0) runningPackage = "com.rekoo.pubgm";
    else if ((ipid = getPID("com.vng.pubgmobile")) != 0) runningPackage = "com.vng.pubgmobile";
    else if ((ipid = getPID("com.pubg.imobile")) != 0) runningPackage = "com.pubg.imobile";

    if (ipid == 0) {
        puts("Failed to get memory!");
        exit(1);
    }
    
    char lj[64];
    sprintf(lj, "/proc/%d/mem", ipid);
    handle = open(lj, O_RDWR);
    if (handle == -1) {
        perror("Failed to open /proc/mem");
        exit(1);
    }
    
    long int libanogs = get_module_base(ipid, "libanogs.so");
    long int gcloud = get_module_base(ipid, "libgcloud.so");
    long int hdmv = get_module_base(ipid, "libhdmpve.so");
    long int ue4 = get_module_base(ipid, "libUE4.so");

    switch (Features) {
        case 1:
            // case 1 logic
          //  edithex(ue4 + 0xb4, "00 00 00 00");
            close(handle);
            break;

        case 999: {

        edithex(libanogs + 0x3ADB58, "00 00 80 D2 C0 03 5F D6");
        edithex(libanogs + 0x5AA5, "00 00 80 D2 C0 03 5F D6");

            close(handle);
            break;
        }

        case 5:
         //   RAYAN_BaseAddress_DWORD(gcloud + 0x421164, 0);
            close(handle);
            break;

        case 6:
         //   RAYAN_BaseAddress_DWORD(gcloud + 0x421164, -1326110034);
            close(handle);
            break;

        default:
            close(handle);
            break;
    }

    return 0;
}
