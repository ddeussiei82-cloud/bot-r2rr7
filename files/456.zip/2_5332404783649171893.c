════════════════════════════════════════════════════════════════════════════════════════════════════
🔴 @IRAQ_Q15 - ELITE ROOT OFFSETS - ARM64 PRECISION HUNTER 🔴
📁 Target: libanogs.so
📅 Generated: 2026-05-28 14:40:37.866033
📊 Total Results (Limited): 55 offsets
📏 Bytes per line: 8
🔧 Template: 2
════════════════════════════════════════════════════════════════════════════════════════════════════

 ========== @IRAQ_Q15 PRIORITY 100-90 ==========

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: BRANCH_LINK
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x402360   RVA: 0x2360
 Hex: 59 00 00 00 00 00 00 00
 PATCH_LIB("libanogs.so", "0x2360", "59 00 00 00 00 00 00 00");
 Hook: install_arm64_hook("libanogs.so", 0x2360, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: Rr...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x5D0EAC   RVA: 0x1D0EAC
 Hex: 28 00 80 52 08 1C 0F 39
 PATCH_LIB("libanogs.so", "0x1D0EAC", "28 00 80 52 08 1C 0F 39");
 Hook: install_arm64_hook("libanogs.so", 0x1D0EAC, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r=...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x5E1218   RVA: 0x1E1218
 Hex: CB 02 00 94 1F 00 00 71
 PATCH_LIB("libanogs.so", "0x1E1218", "CB 02 00 94 1F 00 00 71");
 Hook: install_arm64_hook("libanogs.so", 0x1E1218, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r:...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x610924   RVA: 0x210924
 Hex: 23 FF FF 54 08 21 00 D1
 PATCH_LIB("libanogs.so", "0x210924", "23 FF FF 54 08 21 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x210924, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r)...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x62C68C   RVA: 0x22C68C
 Hex: EB 03 8B 1A AA 5A 6B F8
 PATCH_LIB("libanogs.so", "0x22C68C", "EB 03 8B 1A AA 5A 6B F8");
 Hook: install_arm64_hook("libanogs.so", 0x22C68C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x62CAD4   RVA: 0x22CAD4
 Hex: 08 24 00 A9 08 E1 01 91
 PATCH_LIB("libanogs.so", "0x22CAD4", "08 24 00 A9 08 E1 01 91");
 Hook: install_arm64_hook("libanogs.so", 0x22CAD4, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x670F9C   RVA: 0x270F9C
 Hex: A2 0E 44 A9 E1 03 00 AA
 PATCH_LIB("libanogs.so", "0x270F9C", "A2 0E 44 A9 E1 03 00 AA");
 Hook: install_arm64_hook("libanogs.so", 0x270F9C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x6A660C   RVA: 0x2A660C
 Hex: E0 03 00 AD E0 03 01 AD
 PATCH_LIB("libanogs.so", "0x2A660C", "E0 03 00 AD E0 03 01 AD");
 Hook: install_arm64_hook("libanogs.so", 0x2A660C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: rL...
 ARM64: CMP_W0_0
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x6B6A0C   RVA: 0x2B6A0C
 Hex: E0 03 01 AA E1 83 01 91
 PATCH_LIB("libanogs.so", "0x2B6A0C", "E0 03 01 AA E1 83 01 91");
 Hook: install_arm64_hook("libanogs.so", 0x2B6A0C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: FUNCTION_EPILOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x6E2FE4   RVA: 0x2E2FE4
 Hex: FD 7B 01 A9 FD 43 00 91
 PATCH_LIB("libanogs.so", "0x2E2FE4", "FD 7B 01 A9 FD 43 00 91");
 Hook: install_arm64_hook("libanogs.so", 0x2E2FE4, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: rF...
 ARM64: FUNCTION_PROLOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x70E6D8   RVA: 0x30E6D8
 Hex: FF 43 01 91 C0 03 5F D6
 PATCH_LIB("libanogs.so", "0x30E6D8", "FF 43 01 91 C0 03 5F D6");
 Hook: install_arm64_hook("libanogs.so", 0x30E6D8, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: FUNCTION_PROLOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x7118F4   RVA: 0x3118F4
 Hex: EA FF FF 17 FD 7B 43 A9
 PATCH_LIB("libanogs.so", "0x3118F4", "EA FF FF 17 FD 7B 43 A9");
 Hook: install_arm64_hook("libanogs.so", 0x3118F4, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: FUNCTION_PROLOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x73E6D8   RVA: 0x33E6D8
 Hex: E0 03 40 F9 FD 7B 44 A9
 PATCH_LIB("libanogs.so", "0x33E6D8", "E0 03 40 F9 FD 7B 44 A9");
 Hook: install_arm64_hook("libanogs.so", 0x33E6D8, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x73E73C   RVA: 0x33E73C
 Hex: A9 83 1F F8 E0 0F 00 F9
 PATCH_LIB("libanogs.so", "0x33E73C", "A9 83 1F F8 E0 0F 00 F9");
 Hook: install_arm64_hook("libanogs.so", 0x33E73C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x757F84   RVA: 0x357F84
 Hex: 01 01 40 F9 E0 0F 00 F9
 PATCH_LIB("libanogs.so", "0x357F84", "01 01 40 F9 E0 0F 00 F9");
 Hook: install_arm64_hook("libanogs.so", 0x357F84, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: FUNCTION_EPILOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x76F7B8   RVA: 0x36F7B8
 Hex: E1 07 00 F9 E0 03 00 F9
 PATCH_LIB("libanogs.so", "0x36F7B8", "E1 07 00 F9 E0 03 00 F9");
 Hook: install_arm64_hook("libanogs.so", 0x36F7B8, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: rb...
 ARM64: FUNCTION_EPILOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x7AC108   RVA: 0x3AC108
 Hex: 48 59 68 F8 00 01 1F D6
 PATCH_LIB("libanogs.so", "0x3AC108", "48 59 68 F8 00 01 1F D6");
 Hook: install_arm64_hook("libanogs.so", 0x3AC108, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r8...
 ARM64: FUNCTION_EPILOGUE
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x838B7C   RVA: 0x438B7C
 Hex: E8 07 40 F9 09 01 80 D2
 PATCH_LIB("libanogs.so", "0x438B7C", "E8 07 40 F9 09 01 80 D2");
 Hook: install_arm64_hook("libanogs.so", 0x438B7C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x83D36C   RVA: 0x43D36C
 Hex: 22 00 80 D2 68 00 00 94
 PATCH_LIB("libanogs.so", "0x43D36C", "22 00 80 D2 68 00 00 94");
 Hook: install_arm64_hook("libanogs.so", 0x43D36C, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: NOP
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x86DDC8   RVA: 0x46DDC8
 Hex: E0 03 09 AA E9 03 00 F9
 PATCH_LIB("libanogs.so", "0x46DDC8", "E0 03 09 AA E9 03 00 F9");
 Hook: install_arm64_hook("libanogs.so", 0x46DDC8, "ARM64_HOOK");

 [95] STRING_R | Confidence: 95%
 String: r...
 ARM64: RETURN
 Bypass: ARM64_HOOK
#define OFFSET_STRING_R 0x879CC8   RVA: 0x479CC8
 Hex: 22 00 80 D2 68 00 00 94
 PATCH_LIB("libanogs.so", "0x479CC8", "22 00 80 D2 68 00 00 94");
 Hook: install_arm64_hook("libanogs.so", 0x479CC8, "ARM64_HOOK");

 [91] ANTI_HOOK | Confidence: 91%
 String: hook...
 ARM64: UNKNOWN
 Bypass: HOOK_BYPASS
#define OFFSET_ANTI_HOOK 0x4A0954   RVA: 0xA0954
 Hex: 47 71 75 79 7F 7D 47 7F
 PATCH_LIB("libanogs.so", "0xA0954", "47 71 75 79 7F 7D 47 7F");
 Hook: install_arm64_hook("libanogs.so", 0xA0954, "HOOK_BYPASS");

 [91] ANTI_HOOK | Confidence: 91%
 String: hook...
 ARM64: UNKNOWN
 Bypass: HOOK_BYPASS
#define OFFSET_ANTI_HOOK 0x4A629C   RVA: 0xA629C
 Hex: 72 65 63 74 20 64 61 74
 PATCH_LIB("libanogs.so", "0xA629C", "72 65 63 74 20 64 61 74");
 Hook: install_arm64_hook("libanogs.so", 0xA629C, "HOOK_BYPASS");

 [91] ANTI_HOOK | Confidence: 91%
 String: got...
 ARM64: UNKNOWN
 Bypass: HOOK_BYPASS
#define OFFSET_ANTI_HOOK 0x4A3E60   RVA: 0xA3E60
 Hex: 20 6C 65 61 73 74 20 34
 PATCH_LIB("libanogs.so", "0xA3E60", "20 6C 65 61 73 74 20 34");
 Hook: install_arm64_hook("libanogs.so", 0xA3E60, "HOOK_BYPASS");

 [91] ANTI_HOOK | Confidence: 91%
 String: got...
 ARM64: UNKNOWN
 Bypass: HOOK_BYPASS
#define OFFSET_ANTI_HOOK 0x96C8C0   RVA: 0x56C8C0
 Hex: 00 2E 69 6E 69 74 5F 61
 PATCH_LIB("libanogs.so", "0x56C8C0", "00 2E 69 6E 69 74 5F 61");
 Hook: install_arm64_hook("libanogs.so", 0x56C8C0, "HOOK_BYPASS");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: O@9?9...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6090CC   RVA: 0x2090CC
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2090CC", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2090CC, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: 3@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x619814   RVA: 0x219814
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x219814", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x219814, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: T(}@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x66E8A8   RVA: 0x26E8A8
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x26E8A8", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x26E8A8, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: R!pE...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6803D4   RVA: 0x2803D4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2803D4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2803D4, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: @9*+...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6B2974   RVA: 0x2B2974
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2B2974", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2B2974, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: @9*+...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6B2A2C   RVA: 0x2B2A2C
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2B2A2C", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2B2A2C, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: rHYh...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6DDC58   RVA: 0x2DDC58
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2DDC58", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2DDC58, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: * }@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6E6950   RVA: 0x2E6950
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2E6950", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2E6950, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: * }@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6E6978   RVA: 0x2E6978
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2E6978", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2E6978, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: * }@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6E69AC   RVA: 0x2E69AC
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2E69AC", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2E69AC, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: A@9I...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6EF464   RVA: 0x2EF464
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2EF464", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2EF464, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: O@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6F40AC   RVA: 0x2F40AC
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2F40AC", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2F40AC, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: *k}@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6F42C8   RVA: 0x2F42C8
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2F42C8", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2F42C8, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: 7@9(...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x6F72F4   RVA: 0x2F72F4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x2F72F4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x2F72F4, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: *)}@...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x701664   RVA: 0x301664
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x301664", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x301664, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: *!@9...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x702514   RVA: 0x302514
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x302514", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x302514, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x706EA4   RVA: 0x306EA4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x306EA4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x306EA4, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x706ECC   RVA: 0x306ECC
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x306ECC", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x306ECC, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x706F28   RVA: 0x306F28
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x306F28", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x306F28, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x706F84   RVA: 0x306F84
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x306F84", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x306F84, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x708D9C   RVA: 0x308D9C
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x308D9C", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x308D9C, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x708DC4   RVA: 0x308DC4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x308DC4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x308DC4, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x708E20   RVA: 0x308E20
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x308E20", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x308E20, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9)...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x708E7C   RVA: 0x308E7C
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x308E7C", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x308E7C, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9(...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x70C798   RVA: 0x30C798
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x30C798", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x30C798, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ?@9(...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x70C7CC   RVA: 0x30C7CC
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x30C7CC", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x30C7CC, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: (A=9(E=9...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x717034   RVA: 0x317034
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x317034", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x317034, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: R*A=9...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x718CD4   RVA: 0x318CD4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x318CD4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x318CD4, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: s]8H...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x71A934   RVA: 0x31A934
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x31A934", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x31A934, "INSTRUCTION_HOOK");

 [90] ARM64_FUNCTION_PROLOGUE | Confidence: 95%
 String: ;@9J...
 ARM64: FUNCTION_PROLOGUE
 Bypass: INSTRUCTION_HOOK
#define OFFSET_ARM64_FUNCTION_PROLOGUE 0x720FF4   RVA: 0x320FF4
 Hex: FF 83 00 D1
 PATCH_LIB("libanogs.so", "0x320FF4", "FF 83 00 D1");
 Hook: install_arm64_hook("libanogs.so", 0x320FF4, "INSTRUCTION_HOOK");


 ========== @IRAQ_Q15 PRIORITY 89-80 ==========


 ========== @IRAQ_Q15 PRIORITY 79-70 ==========


 ========== @IRAQ_Q15 ARM64 HOOK TEMPLATE ==========

